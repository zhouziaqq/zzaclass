/**
 * data/default-schedule.js
 * 内置默认课表：由 tools/build-data.mjs 从 PDF 自动生成，请勿手工修改。
 * 生成时间：2026-09-13T13:06:11.673Z
 * 来源文件：周子奥(2026-2027-1)课表.pdf
 * 统计：5 天 / 26 门次课 / 4 条其他课程
 */
window.DEFAULT_SCHEDULE = {
  "meta": {
    "student": "周子奥",
    "studentId": "1361****6026",
    "term": "2026-2027学年第1学期",
    "printedAt": "2026-09-13",
    "source": "周子奥(2026-2027-1)课表.pdf",
    "importedAt": "2026-09-13T13:06:11.670Z"
  },
  "days": [
    {
      "day": 1,
      "name": "星期一",
      "slots": [
        {
          "label": "1-2",
          "start": 1,
          "end": 2,
          "courses": [
            {
              "name": "大学英语（一）",
              "weeks": "2-5周,8-19周",
              "weekRanges": [
                [
                  2,
                  5
                ],
                [
                  8,
                  19
                ]
              ],
              "campus": "旗山校区",
              "location": "致广1-211",
              "teachers": "任超",
              "className": "大学英语（一）-光电2",
              "classInfo": "2026",
              "note": "",
              "hours": "讲课学时:32/周学时:2/总学时:32"
            }
          ]
        },
        {
          "label": "3-4",
          "start": 3,
          "end": 4,
          "courses": [
            {
              "name": "工程基础（一）",
              "weeks": "2-5周,8-15周",
              "weekRanges": [
                [
                  2,
                  5
                ],
                [
                  8,
                  15
                ]
              ],
              "campus": "旗山校区",
              "location": "笃行1-308",
              "teachers": "向益峰",
              "className": "工程基础（一）-0002",
              "classInfo": "2026级电子信息工程（中英）",
              "note": "",
              "hours": "讲课学时:48/周学时:3/总学时:48"
            }
          ]
        },
        {
          "label": "5-6",
          "start": 5,
          "end": 6,
          "courses": [
            {
              "name": "交流与研究（一）",
              "weeks": "3-5周,8周",
              "weekRanges": [
                [
                  3,
                  5
                ],
                [
                  8,
                  8
                ]
              ],
              "campus": "旗山校区",
              "location": "笃行1-408",
              "teachers": "Muhammad Salman Bashir,花强",
              "className": "交流与研究（一）-0002",
              "classInfo": "2026级电子信息工程（中英）",
              "note": "",
              "hours": "讲课学时:32,课程实践学时:16/周学时:2/总学时:32"
            },
            {
              "name": "交流与研究（二）",
              "weeks": "9-12周",
              "weekRanges": [
                [
                  9,
                  12
                ]
              ],
              "campus": "旗山校区",
              "location": "笃行1-109",
              "teachers": "Muhammad Salman Bashir,花强",
              "className": "交流与研究（二）-0002",
              "classInfo": "2026级电子信息工程（中英）",
              "note": "",
              "hours": "讲课学时:32,课程实践学时:16/周学时:2/总学时:32"
            }
          ]
        },
        {
          "label": "7-8",
          "start": 7,
          "end": 8,
          "courses": [
            {
              "name": "数学基础（一）",
              "weeks": "3-5周,8-10周",
              "weekRanges": [
                [
                  3,
                  5
                ],
                [
                  8,
                  10
                ]
              ],
              "campus": "旗山校区",
              "location": "笃行1-308",
              "teachers": "Muhammad Salman Bashir",
              "className": "数学基础（一）-0003",
              "classInfo": "2026级电子信息工程（中英）",
              "note": "",
              "hours": "讲课学时:32,课程实践学时:32/周学时:2/总学时:32"
            },
            {
              "name": "数学基础（二）",
              "weeks": "11-16周",
              "weekRanges": [
                [
                  11,
                  16
                ]
              ],
              "campus": "旗山校区",
              "location": "立诚1-104",
              "teachers": "Muhammad Salman Bashir",
              "className": "数学基础（二）-0002",
              "classInfo": "2026级电子信息工程（中英）",
              "note": "",
              "hours": "讲课学时:32,课程实践学时:32/周学时:2/总学时:32"
            }
          ]
        }
      ]
    },
    {
      "day": 2,
      "name": "星期二",
      "slots": [
        {
          "label": "1-2",
          "start": 1,
          "end": 2,
          "courses": [
            {
              "name": "交流与研究（一）",
              "weeks": "3-5周,8-10周",
              "weekRanges": [
                [
                  3,
                  5
                ],
                [
                  8,
                  10
                ]
              ],
              "campus": "旗山校区",
              "location": "立诚1-205",
              "teachers": "Muhammad Salman Bashir,花强",
              "className": "交流与研究（一）-0002",
              "classInfo": "2026级电子信息工程（中英）",
              "note": "",
              "hours": "讲课学时:32,课程实践学时:16/周学时:2/总学时:32"
            },
            {
              "name": "交流与研究（二）",
              "weeks": "11-16周",
              "weekRanges": [
                [
                  11,
                  16
                ]
              ],
              "campus": "旗山校区",
              "location": "立诚1-205",
              "teachers": "Muhammad Salman Bashir,花强",
              "className": "交流与研究（二）-0002",
              "classInfo": "2026级电子信息工程（中英）",
              "note": "",
              "hours": "讲课学时:32,课程实践学时:16/周学时:2/总学时:32"
            }
          ]
        },
        {
          "label": "3-4",
          "start": 3,
          "end": 4,
          "courses": [
            {
              "name": "工程调查研究(一）",
              "weeks": "2-5周,8-19周",
              "weekRanges": [
                [
                  2,
                  5
                ],
                [
                  8,
                  19
                ]
              ],
              "campus": "旗山校区",
              "location": "笃行1-220",
              "teachers": "郑华",
              "className": "工程调查研究(一）-0002",
              "classInfo": "2026级电子信息工程（中英）",
              "note": "",
              "hours": "讲课学时:32/周学时:2/总学时:32"
            }
          ]
        },
        {
          "label": "7-8",
          "start": 7,
          "end": 8,
          "courses": [
            {
              "name": "工程基础（一）",
              "weeks": "2-5周,8-15周",
              "weekRanges": [
                [
                  2,
                  5
                ],
                [
                  8,
                  15
                ]
              ],
              "campus": "旗山校区",
              "location": "笃行1-407",
              "teachers": "向益峰",
              "className": "工程基础（一）-0002",
              "classInfo": "2026级电子信息工程（中英）",
              "note": "",
              "hours": "讲课学时:48/周学时:3/总学时:48"
            }
          ]
        }
      ]
    },
    {
      "day": 3,
      "name": "星期三",
      "slots": [
        {
          "label": "3-4",
          "start": 3,
          "end": 4,
          "courses": [
            {
              "name": "学术英语",
              "weeks": "2-5周,8-19周",
              "weekRanges": [
                [
                  2,
                  5
                ],
                [
                  8,
                  19
                ]
              ],
              "campus": "旗山校区",
              "location": "笃行1-214",
              "teachers": "林立",
              "className": "学术英语-0002",
              "classInfo": "2026级电子信息工程（中英）",
              "note": "",
              "hours": "讲课学时:48/周学时:3/总学时:48"
            }
          ]
        }
      ]
    },
    {
      "day": 4,
      "name": "星期四",
      "slots": [
        {
          "label": "1-2",
          "start": 1,
          "end": 2,
          "courses": [
            {
              "name": "交流与研究（一）",
              "weeks": "3-5周,8-10周",
              "weekRanges": [
                [
                  3,
                  5
                ],
                [
                  8,
                  10
                ]
              ],
              "campus": "旗山校区",
              "location": "笃行1-409",
              "teachers": "Muhammad Salman Bashir,花强",
              "className": "交流与研究（一）-0002",
              "classInfo": "2026级电子信息工程（中英）",
              "note": "",
              "hours": "讲课学时:32,课程实践学时:16/周学时:2/总学时:32"
            },
            {
              "name": "数学基础（二）",
              "weeks": "11-12周",
              "weekRanges": [
                [
                  11,
                  12
                ]
              ],
              "campus": "旗山校区",
              "location": "笃行1-112",
              "teachers": "Muhammad Salman Bashir",
              "className": "数学基础（二）-0002",
              "classInfo": "2026级电子信息工程（中英）",
              "note": "",
              "hours": "讲课学时:32,课程实践学时:32/周学时:2/总学时:32"
            },
            {
              "name": "交流与研究（二）",
              "weeks": "13-16周",
              "weekRanges": [
                [
                  13,
                  16
                ]
              ],
              "campus": "旗山校区",
              "location": "笃行1-407",
              "teachers": "Muhammad Salman Bashir,花强",
              "className": "交流与研究（二）-0002",
              "classInfo": "2026级电子信息工程（中英）",
              "note": "",
              "hours": "讲课学时:32,课程实践学时:16/周学时:2/总学时:32"
            }
          ]
        },
        {
          "label": "3-4",
          "start": 3,
          "end": 4,
          "courses": [
            {
              "name": "学术英语",
              "weeks": "2-5周,8-10周",
              "weekRanges": [
                [
                  2,
                  5
                ],
                [
                  8,
                  10
                ]
              ],
              "campus": "旗山校区",
              "location": "笃行1-307",
              "teachers": "林立",
              "className": "学术英语-0002",
              "classInfo": "2026级电子信息工程（中英）",
              "note": "",
              "hours": "讲课学时:48/周学时:3/总学时:48"
            }
          ]
        },
        {
          "label": "5-6",
          "start": 5,
          "end": 6,
          "courses": [
            {
              "name": "专业导论与生涯规划",
              "weeks": "2-3周",
              "weekRanges": [
                [
                  2,
                  3
                ]
              ],
              "campus": "旗山校区",
              "location": "笃行1-508",
              "teachers": "黄果池",
              "className": "2026级电子信息工程（中英）",
              "classInfo": "2026级电子信息工程（中英）",
              "note": "",
              "hours": "讲课学时:16/周学时:1/总学时:16"
            },
            {
              "name": "专业导论与生涯规划",
              "weeks": "4-5周",
              "weekRanges": [
                [
                  4,
                  5
                ]
              ],
              "campus": "旗山校区",
              "location": "笃行1-508",
              "teachers": "施文灶",
              "className": "2026级电子信息工程（中英）",
              "classInfo": "2026级电子信息工程（中英）",
              "note": "",
              "hours": "讲课学时:16/周学时:1/总学时:16"
            },
            {
              "name": "专业导论与生涯规划",
              "weeks": "8-9周",
              "weekRanges": [
                [
                  8,
                  9
                ]
              ],
              "campus": "旗山校区",
              "location": "笃行1-508",
              "teachers": "郑华",
              "className": "2026级电子信息工程（中英）",
              "classInfo": "2026级电子信息工程（中英）",
              "note": "",
              "hours": "讲课学时:16/周学时:1/总学时:16"
            }
          ]
        },
        {
          "label": "7-8",
          "start": 7,
          "end": 8,
          "courses": [
            {
              "name": "数学基础（一）",
              "weeks": "3-5周,8-10周",
              "weekRanges": [
                [
                  3,
                  5
                ],
                [
                  8,
                  10
                ]
              ],
              "campus": "旗山校区",
              "location": "笃行1-112",
              "teachers": "Muhammad Salman Bashir",
              "className": "数学基础（一）-0003",
              "classInfo": "2026级电子信息工程（中英）",
              "note": "",
              "hours": "讲课学时:32,课程实践学时:32/周学时:2/总学时:32"
            },
            {
              "name": "数学基础（二）",
              "weeks": "11-16周",
              "weekRanges": [
                [
                  11,
                  16
                ]
              ],
              "campus": "旗山校区",
              "location": "笃行1-308",
              "teachers": "Muhammad Salman Bashir",
              "className": "数学基础（二）-0002",
              "classInfo": "2026级电子信息工程（中英）",
              "note": "",
              "hours": "讲课学时:32,课程实践学时:32/周学时:2/总学时:32"
            }
          ]
        }
      ]
    },
    {
      "day": 5,
      "name": "星期五",
      "slots": [
        {
          "label": "1-2",
          "start": 1,
          "end": 2,
          "courses": [
            {
              "name": "数学基础（一）",
              "weeks": "3-5周,8周",
              "weekRanges": [
                [
                  3,
                  5
                ],
                [
                  8,
                  8
                ]
              ],
              "campus": "旗山校区",
              "location": "笃行1-112",
              "teachers": "Muhammad Salman Bashir",
              "className": "数学基础（一）-0003",
              "classInfo": "2026级电子信息工程（中英）",
              "note": "",
              "hours": "讲课学时:32,课程实践学时:32/周学时:2/总学时:32"
            },
            {
              "name": "数学基础（二）",
              "weeks": "9-10周",
              "weekRanges": [
                [
                  9,
                  10
                ]
              ],
              "campus": "旗山校区",
              "location": "笃行1-112",
              "teachers": "Muhammad Salman Bashir",
              "className": "数学基础（二）-0002",
              "classInfo": "2026级电子信息工程（中英）",
              "note": "",
              "hours": "讲课学时:32,课程实践学时:32/周学时:2/总学时:32"
            },
            {
              "name": "交流与研究（二）",
              "weeks": "11-12周",
              "weekRanges": [
                [
                  11,
                  12
                ]
              ],
              "campus": "旗山校区",
              "location": "笃行1-112",
              "teachers": "Muhammad Salman Bashir,花强",
              "className": "交流与研究（二）-0002",
              "classInfo": "2026级电子信息工程（中英）",
              "note": "",
              "hours": "讲课学时:32,课程实践学时:16/周学时:2/总学时:32"
            }
          ]
        },
        {
          "label": "3-4",
          "start": 3,
          "end": 4,
          "courses": [
            {
              "name": "概论1",
              "weeks": "12-19周",
              "weekRanges": [
                [
                  12,
                  19
                ]
              ],
              "campus": "旗山校区",
              "location": "致广1-201",
              "teachers": "王有加",
              "className": "思想政治理论课1-1-0052",
              "classInfo": "2026级电子信息工程（中英）",
              "note": "",
              "hours": "讲课学时:16/周学时:2/总学时:16"
            }
          ]
        },
        {
          "label": "5-6",
          "start": 5,
          "end": 6,
          "courses": [
            {
              "name": "原理",
              "weeks": "2-5周,8-19周",
              "weekRanges": [
                [
                  2,
                  5
                ],
                [
                  8,
                  19
                ]
              ],
              "campus": "旗山校区",
              "location": "立诚1-201",
              "teachers": "郑朝静",
              "className": "思想政治理论课2-0033",
              "classInfo": "2026级电子信息工程（中英）",
              "note": "",
              "hours": "讲课学时:32/周学时:2/总学时:32"
            }
          ]
        },
        {
          "label": "7-8",
          "start": 7,
          "end": 8,
          "courses": [
            {
              "name": "专业导论与生涯规划",
              "weeks": "10-11周",
              "weekRanges": [
                [
                  10,
                  11
                ]
              ],
              "campus": "旗山校区",
              "location": "笃行1-307",
              "teachers": "林潇",
              "className": "2026级电子信息工程（中英）",
              "classInfo": "2026级电子信息工程（中英）",
              "note": "",
              "hours": "讲课学时:16/周学时:1/总学时:16"
            }
          ]
        }
      ]
    }
  ],
  "others": [
    {
      "name": "数学基础（一）",
      "teachers": "Muhammad Salman Bashir",
      "totalWeeks": "16",
      "weeks": "1-16周",
      "location": "无",
      "raw": "数学基础（一）Muhammad Salman Bashir(共16周)/1-16周/无"
    },
    {
      "name": "数学基础（二）",
      "teachers": "Muhammad Salman Bashir",
      "totalWeeks": "16",
      "weeks": "1-16周",
      "location": "无",
      "raw": "数学基础（二）Muhammad Salman Bashir(共16周)/1-16周/无"
    },
    {
      "name": "交流与研究（一）",
      "teachers": "Muhammad Salman Bashir,花强",
      "totalWeeks": "8",
      "weeks": "12-19周",
      "location": "无",
      "raw": "交流与研究（一）Muhammad Salman Bashir,花强(共8周)/12-19周/无"
    },
    {
      "name": "交流与研究（二）",
      "teachers": "Muhammad Salman Bashir,花强",
      "totalWeeks": "8",
      "weeks": "12-19周",
      "location": "无",
      "raw": "交流与研究（二）Muhammad Salman Bashir,花强(共8周)/12-19周/无"
    }
  ],
  "warnings": [],
  "pageCount": 2
};
