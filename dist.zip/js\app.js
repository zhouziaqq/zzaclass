/**
 * app.js —— 界面逻辑：今天视图 / 周课表 / 导入 PDF / 设置
 * 依赖（由 index.html 里前面的 script 标签提供）：
 *   window.TimetablePdf / window.Times / window.DateUtils / window.Store / window.DEFAULT_SCHEDULE
 */
(function () {
'use strict';

const { inWeeks, parseTimetablePdf } = window.TimetablePdf;
const { BLOCKS, MAX_PERIODS, PERIOD_TIMES, formatMinutes, gapBetween, periodTime, slotTime } = window.Times;
const CustomCourses = window.CustomCourses;
const Device = window.Device;
const {
  WEEKDAY_NAMES, addDays, dateOfWeek, formatDate, humanDate, isSameDay, parseDate, startOfWeek, teachingWeek, today, weekdayIndex
} = window.DateUtils;
const store = window.Store;

const state = store.load();
let schedule = store.currentSchedule(state);
let selectedDate = today();

const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];
const esc = (s) => String(s == null ? '' : s)
  .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

const HUES = [214, 262, 330, 8, 32, 152, 176, 286, 44, 196];
const BLOCK_LABEL = { am: '上午', pm: '下午', night: '晚上' };

function courseHue(name) {
  let n = 7;
  for (const ch of String(name || '')) n = (n * 31 + ch.codePointAt(0)) % 9973;
  return HUES[n % HUES.length];
}

function dayEntry(dayIndex) {
  return (schedule.days || []).find((d) => d.day === dayIndex) || null;
}

/** 当前是否手机端（由 <html data-device> 决定） */
function isMobileMode() {
  return document.documentElement.dataset.device === 'mobile';
}

// ------------------------------------------------- 电脑端 / 手机端

let weekStripDay = null; // 手机端周课表里选中的星期

function applyDeviceMode() {
  const mode = Device.effective(state.device || 'auto');
  Device.apply(mode);
  const btn = $('#btnDevice');
  if (btn) {
    btn.textContent = mode === 'mobile' ? '🖥️' : '📱';
    btn.title = mode === 'mobile' ? '切换到电脑版' : '切换到手机版';
    btn.setAttribute('aria-label', btn.title);
  }
  const sel = $('#deviceMode');
  if (sel) sel.value = state.device || 'auto';
  return mode;
}

function toggleDeviceMode() {
  const current = isMobileMode() ? 'mobile' : 'desktop';
  const next = current === 'mobile' ? 'desktop' : 'mobile';
  state.device = next;
  store.save(state);
  weekStripDay = null;
  applyDeviceMode();
  renderAll();
  toast(next === 'mobile'
    ? '已切换到手机版：导航挪到屏幕底部，课程改成点一下展开'
    : '已切换到电脑版：宽屏布局，鼠标悬停展开课程信息');
}

function setDeviceMode(mode) {
  state.device = mode === 'mobile' || mode === 'desktop' ? mode : 'auto';
  store.save(state);
  weekStripDay = null;
  const applied = applyDeviceMode();
  renderAll();
  toast(state.device === 'auto'
    ? `已改为自动识别（当前判定：${Device.label(applied)}）`
    : `已固定为${Device.label(state.device)}`);
}

/** 取某天（可过滤教学周）的课程明细，包含自建课程 */
function lessonsOf(date, { filterWeek = true } = {}) {
  const week = teachingWeek(date, state.termStart);
  const entry = dayEntry(weekdayIndex(date));
  const lessons = [];
  const useFilter = filterWeek && !state.showAllWeeks && week >= 1;
  if (entry) {
    for (const slot of entry.slots) {
      for (const course of slot.courses) {
        if (useFilter && !inWeeks(course.weekRanges, week)) continue;
        lessons.push({ slot, course, time: slotTime(slot.start, slot.end) });
      }
    }
  }
  // 自建课程（长期 / 部分时间段）与 PDF 课表合并展示
  const custom = CustomCourses.coursesForDate(state.custom || [], date, week, {
    showAllWeeks: state.showAllWeeks
  });
  for (const item of custom) {
    lessons.push({ slot: item.slot, course: item.course, time: slotTime(item.slot.start, item.slot.end) });
  }
  lessons.sort((a, b) => (a.slot.start || 99) - (b.slot.start || 99));
  return { week, lessons };
}

/** 一节课相对「现在」的状态（仅当天有值） */
function lessonStatus(lesson, date) {
  if (!isSameDay(date, today())) return '';
  const now = new Date();
  const mins = now.getHours() * 60 + now.getMinutes();
  if (mins >= lesson.time.startMinutes && mins < lesson.time.endMinutes) return 'now';
  return mins < lesson.time.startMinutes ? 'upcoming' : 'past';
}

function courseDetailHtml(course, extra = []) {
  const rows = [
    ['教师', course.teachers],
    ['周次', course.weeks],
    ['校区', course.campus],
    ['地点', course.location],
    ['教学班', course.className],
    ['班级组成', course.classInfo],
    ['学时', course.hours],
    ['备注', course.note],
    ...extra
  ].filter(([, v]) => v);
  return `<dl class="detail-grid">${rows
    .map(([k, v]) => `<div class="detail-row"><dt>${esc(k)}</dt><dd>${esc(v)}</dd></div>`)
    .join('')}</dl>`;
}

/** 未来几天里最近的几节课（用于「这天没课」时给点提示） */
function upcomingLessons(from, limit = 4) {
  const out = [];
  for (let i = 1; i <= 7 && out.length < limit; i++) {
    const date = addDays(from, i);
    const { lessons } = lessonsOf(date);
    for (const lesson of lessons) {
      out.push({ ...lesson, date });
      if (out.length >= limit) break;
    }
  }
  return out;
}

function lessonCardHtml(lesson, date, index = 0) {
  const { course, slot, time } = lesson;
  const status = lessonStatus(lesson, date);
  const statusText = { now: '正在上课', upcoming: '即将开始', past: '已结束' }[status] || '';
  return `<div class="lesson ${status || ''}" style="--hue:${courseHue(course.name)};--i:${index}">
    <div class="lesson-time">
      <span class="t-start">${time.start}</span>
      <span class="t-end">${time.end}</span>
    </div>
    <article class="lesson-card" tabindex="0">
      <header class="lesson-head">
        <span class="lesson-slot">${esc(slot.label)} 节</span>
        <h3 class="lesson-name">${esc(course.name)}${course.custom ? '<span class="tag-custom">自建</span>' : ''}</h3>
        ${statusText ? `<span class="lesson-status ${status}">${statusText}</span>` : ''}
      </header>
      <p class="lesson-place">
        <span class="pin">📍</span>${esc(course.location || '地点待定')}
        ${course.campus ? `<span class="sep">·</span>${esc(course.campus)}` : ''}
        ${course.teachers ? `<span class="sep">·</span>${esc(course.teachers.split(',')[0])}` : ''}
      </p>
      <div class="lesson-extra">
        <div class="lesson-extra-inner">${courseDetailHtml(course, [['节次时间', `${slot.label} 节 ${time.start}–${time.end}`]])}</div>
      </div>
      <span class="hover-hint">悬停 / 聚焦查看全部信息</span>
    </article>
  </div>`;
}

/** 卡片格式：按上午 / 下午 / 晚上分组的大卡片 */
function dayCardsHtml(lessons, date) {
  if (!lessons.length) return '';
  const groups = BLOCKS
    .map((block) => ({
      ...block,
      items: lessons
        .filter((l) => l.slot.start >= block.from && l.slot.start <= block.to)
        .sort((a, b) => a.slot.start - b.slot.start)
    }))
    .filter((g) => g.items.length);

  const breakRow = (gap) => `<div class="break-row"><span>${gap.name}</span>
      <small>${gap.start} – ${gap.end} · ${gap.minutes} 分钟</small></div>`;

  let html = '';
  let index = 0;
  groups.forEach((group, idx) => {
    const first = group.items[0];
    const last = group.items[group.items.length - 1];
    html += `<div class="block-title">
      <span class="block-name">${BLOCK_LABEL[group.id]}</span>
      <span class="block-range">${first.time.start} – ${last.time.end}</span>
      <span class="block-count">${group.items.length} 节</span>
    </div>`;
    // 同一个时段内，比正常课间更长的间隔（如第 2 节后的大课间）也插一条提示
    html += `<div class="lesson-list">${group.items.map((l, i) => {
      const prev = group.items[i - 1];
      const between = prev ? gapBetween(prev.slot.end, l.slot.start) : null;
      return (between ? breakRow(between) : '') + lessonCardHtml(l, date, index++);
    }).join('')}</div>`;
    const next = groups[idx + 1];
    if (next) {
      const gap = gapBetween(last.slot.end, next.items[0].slot.start);
      if (gap) html += breakRow(gap);
    }
  });
  return html;
}

/** 紧凑列表格式：一行一节课，悬停展开全部信息 */
function dayCompactHtml(lessons, date) {
  if (!lessons.length) return '';
  const head = `<div class="cct-head">
    <span>时间</span><span>节次</span><span>课程</span><span>地点</span><span>教师</span><span>周次</span>
  </div>`;
  let index = 0;
  const body = BLOCKS
    .map((block) => ({
      ...block,
      items: lessons.filter((l) => l.slot.start >= block.from && l.slot.start <= block.to)
        .sort((a, b) => a.slot.start - b.slot.start)
    }))
    .filter((g) => g.items.length)
    .map((group) => {
      const first = group.items[0];
      const last = group.items[group.items.length - 1];
      const rows = group.items.map((l) => {
        const { course, slot, time } = l;
        const status = lessonStatus(l, date);
        return `<div class="cct-row" tabindex="0" style="--hue:${courseHue(course.name)};--i:${index++}">
          <span class="cct-time">${time.start}<small>${time.end}</small></span>
          <span class="cct-slot">${esc(slot.label)} 节</span>
          <span class="cct-name">${esc(course.name)}${course.custom ? '<span class="tag-custom">自建</span>' : ''}
            ${status === 'now' ? '<span class="lesson-status now">正在上课</span>' : ''}</span>
          <span class="cct-place">${esc(course.location || '—')}</span>
          <span class="cct-teacher">${esc((course.teachers || '—').split(',')[0])}</span>
          <span class="cct-weeks">${esc(course.weeks || '—')}</span>
          <div class="cct-extra"><div class="cct-extra-inner">${courseDetailHtml(course, [['节次', `${slot.label} 节`], ['时间', `${time.start} – ${time.end}`]])}</div></div>
        </div>`;
      }).join('');
      return `<div class="block-title"><span class="block-name">${BLOCK_LABEL[group.id]}</span>
        <span class="block-range">${first.time.start} – ${last.time.end}</span>
        <span class="block-count">${group.items.length} 节</span></div>${rows}`;
    }).join('');
  return `<div class="cct">${head}${body}</div>`;
}

/** 时间轴格式：按时间比例排列的彩色条，带「现在」指示线 */
function dayTimelineFormatHtml(lessons, date) {
  if (!lessons.length) return '';
  const sorted = lessons.slice().sort((a, b) => a.time.startMinutes - b.time.startMinutes);
  const firstMin = sorted[0].time.startMinutes;
  const lastMin = Math.max(...sorted.map((l) => l.time.endMinutes));
  const span = Math.max(60, lastMin - firstMin);
  const height = Math.min(920, Math.max(420, Math.round(span * 0.95)));
  const pos = (minutes) => ((minutes - firstMin) / span) * 100;

  const hours = [];
  for (let m = Math.ceil(firstMin / 60) * 60; m <= lastMin; m += 60) hours.push(m);

  let index = 0;
  const blocks = sorted.map((l) => {
    const status = lessonStatus(l, date);
    const top = pos(l.time.startMinutes);
    const heightPct = ((l.time.endMinutes - l.time.startMinutes) / span) * 100;
    return `<div class="tl-block${status === 'now' ? ' is-now' : ''}" tabindex="0"
      style="--hue:${courseHue(l.course.name)};--i:${index++};top:${top}%;height:${heightPct}%">
      <div class="tl-head">
        <span class="tl-time">${l.time.start}–${l.time.end}</span>
        <span class="tl-name">${esc(l.course.name)}${l.course.custom ? '<span class="tag-custom">自建</span>' : ''}</span>
      </div>
      <span class="tl-place">📍 ${esc(l.course.location || '地点待定')}${l.course.teachers ? ` · ${esc(l.course.teachers.split(',')[0])}` : ''}
        ${status === 'now' ? ' · 正在上课' : ''}</span>
      <div class="tl-detail">${courseDetailHtml(l.course, [['节次', `${l.slot.label} 节`], ['时间', `${l.time.start} – ${l.time.end}`]])}</div>
    </div>`;
  }).join('');

  const gaps = [];
  for (let i = 1; i < sorted.length; i++) {
    const prev = sorted[i - 1];
    const gap = gapBetween(prev.slot.end, sorted[i].slot.start);
    if (gap) {
      const mid = (prev.time.endMinutes + sorted[i].time.startMinutes) / 2;
      gaps.push(`<div class="tl-gap" style="top:${pos(mid)}%"><span>${gap.name} ${gap.start}–${gap.end}</span></div>`);
    }
  }

  const now = new Date();
  const nowMin = now.getHours() * 60 + now.getMinutes();
  const nowLine = isSameDay(date, today()) && nowMin >= firstMin && nowMin <= lastMin
    ? `<div class="tl-now" style="top:${pos(nowMin)}%"><span>现在 ${formatMinutes(nowMin)}</span></div>`
    : '';

  return `<div class="tl-wrap"><div class="tl-canvas" style="--tl-height:${height}px">
    <div class="tl-axis"></div>
    ${hours.map((m) => `<span class="tl-hour" style="top:${pos(m)}%">${formatMinutes(m)}</span>`).join('')}
    ${gaps.join('')}
    ${blocks}
    ${nowLine}
  </div></div>`;
}


function emptyStateHtml(date) {
  const upcoming = upcomingLessons(date, 4);
  return `<div class="empty">
    <div class="empty-emoji">🍖</div>
    <p class="empty-title">肘子大王说：${humanDate(date)} 没有课</p>
    <p class="empty-sub">${state.showAllWeeks ? '教务系统的课表里这一天本来就没有排课，去加个鸡腿吧 🍗' : '已按教学周过滤：这一天在课表里没有安排（也可能是该周次课程不在此日）。'}</p>
    <div class="empty-actions">
      <button class="btn" data-day-step="1">看后一天</button>
      <button class="btn ghost" data-switch-view="week">看整周</button>
      <button class="btn ghost" data-add-course>＋ 添加课程</button>
    </div>
    ${upcoming.length ? `<div class="upcoming">
      <p class="upcoming-title">接下来还有</p>
      <ul>${upcoming.map((l) => `<li>
        <span class="up-date">${l.date.getMonth() + 1}/${l.date.getDate()} ${WEEKDAY_NAMES[weekdayIndex(l.date) - 1].slice(2)}</span>
        <span class="up-time">${l.time.start}</span>
        <span class="up-name">${esc(l.course.name)}</span>
        <span class="up-place">${esc(l.course.location || '')}</span>
      </li>`).join('')}</ul>
    </div>` : ''}
  </div>`;
}

function otherCoursesHtml() {
  const others = schedule.others || [];
  if (!others.length) return '';
  return `<section class="others">
    <h2>其他课程<small>暂未排入周课表</small></h2>
    <ul>${others.map((o) => `<li>
      <span class="other-name">${esc(o.name)}</span>
      ${o.teachers ? `<span class="other-teacher">${esc(o.teachers)}</span>` : ''}
      <span class="other-weeks">${esc(o.weeks)}${o.totalWeeks ? `（共 ${esc(o.totalWeeks)} 周）` : ''}</span>
      <span class="other-place">${esc(o.location || '')}</span>
    </li>`).join('')}</ul>
  </section>`;
}

function renderDay() {
  const { week, lessons } = lessonsOf(selectedDate);
  const isToday = isSameDay(selectedDate, today());
  const nowLesson = lessons.find((l) => lessonStatus(l, selectedDate) === 'now');
  const nextLesson = lessons.find((l) => lessonStatus(l, selectedDate) === 'upcoming');

  $('#dayHero').innerHTML = `
    <button class="nav-btn" data-day-step="-1" title="前一天" aria-label="前一天">‹</button>
    <div class="hero-main">
      <div class="hero-top">
        <span class="hero-date">${humanDate(selectedDate)}</span>
        ${isToday ? '<span class="chip chip-today">今天</span>' : ''}
      </div>
      <div class="hero-chips">
        <span class="chip chip-week">${week > 0 ? `第 ${week} 教学周` : '未开学'}</span>
        <span class="chip">共 ${lessons.length} 节</span>
        ${nowLesson ? `<span class="chip chip-live">正在上 · ${esc(nowLesson.course.name)}</span>` : ''}
        ${!nowLesson && nextLesson ? `<span class="chip chip-next">下一节 ${nextLesson.time.start} · ${esc(nextLesson.course.name)}</span>` : ''}
        ${state.showAllWeeks ? '<span class="chip chip-warn">未按教学周过滤</span>' : ''}
      </div>
    </div>
    <div class="hero-actions">
      <button class="btn ghost small" data-goto-today ${isToday ? 'disabled' : ''}>回到今天</button>
      <button class="nav-btn" data-day-step="1" title="后一天" aria-label="后一天">›</button>
    </div>`;

  $('#dayBody').innerHTML = lessons.length
    ? DAY_FORMATS[state.dayFormat || 'card'](lessons, selectedDate)
    : emptyStateHtml(selectedDate);
  $('#othersSlot').innerHTML = otherCoursesHtml();
}

/** 当天视图的三种格式 */
const DAY_FORMATS = {
  card: dayCardsHtml,
  compact: dayCompactHtml,
  timeline: dayTimelineFormatHtml
};
const DAY_FORMAT_LABELS = { card: '卡片', compact: '紧凑列表', timeline: '时间轴' };

/** 周课表里的课程块：默认只显示课程名 + 地点，悬停展开全部信息 */
function weekChipHtml(lesson, index = 0) {
  const { course, slot, time } = lesson;
  return `<div class="wchip${course.custom ? ' is-custom' : ''}" style="--hue:${courseHue(course.name)};--i:${index}" tabindex="0">
    <span class="wchip-name">${esc(course.name)}${course.custom ? '<span class="tag-custom">自建</span>' : ''}</span>
    <span class="wchip-place">${esc(course.location || '地点待定')}</span>
    <div class="wchip-detail">
      <p class="wd-title">${esc(course.name)}</p>
      ${courseDetailHtml(course, [['节次', `${slot.label} 节`], ['时间', `${time.start} – ${time.end}`]])}
    </div>
  </div>`;
}

/** 周课表节次栏里的休息提示：午休 / 晚饭 / 大课间 */
function breakTagFor(period) {
  const gap = gapBetween(period - 1, period);
  return gap ? gap.name : '';
}

function renderWeek() {
  const week = Math.max(teachingWeek(selectedDate, state.termStart), 1);
  const days = (schedule.days || []).slice().sort((a, b) => a.day - b.day);
  const periodCount = 12;

  const byDay = new Map();
  for (const d of days) {
    const date = dateOfWeek(state.termStart, week, d.day);
    byDay.set(d.day, { date, lessons: lessonsOf(date).lessons, isToday: isSameDay(date, today()) });
  }
  const totalLessons = [...byDay.values()].reduce((n, v) => n + v.lessons.length, 0);

  const head = `<div class="wg-corner">节次 / 时间</div>${days.map((d) => {
    const info = byDay.get(d.day);
    return `<div class="wg-day${info.isToday ? ' is-today' : ''}" data-date="${formatDate(info.date)}"
      role="button" tabindex="0" title="查看当天详情">
      <span class="wg-day-name">${esc(d.name)}</span>
      <span class="wg-day-date">${info.date.getMonth() + 1}/${info.date.getDate()}</span>
      <span class="wg-day-count">${info.lessons.length} 节</span>
    </div>`;
  }).join('')}`;

  let body = '';
  for (let p = 1; p <= periodCount; p++) {
    const time = PERIOD_TIMES[p - 1];
    const breakTag = breakTagFor(p);
    body += `<div class="wg-time${breakTag ? ' has-break' : ''}">
      <span class="wg-period">第 ${p} 节</span>
      <span class="wg-clock">${time.start}–${time.end}</span>
      ${breakTag ? `<span class="wg-break">${breakTag}</span>` : ''}
    </div>`;
    for (const d of days) {
      const { lessons } = byDay.get(d.day);
      const starting = lessons.filter((l) => l.slot.start === p);
      const covered = lessons.some((l) => l.slot.start < p && l.slot.end >= p);
      if (starting.length) {
        const span = Math.max(1, ...starting.map((l) => Math.max(1, (l.slot.end || l.slot.start) - l.slot.start + 1)));
        body += `<div class="wg-cell has-course" style="grid-row:span ${span}">${starting.map((l, i) => weekChipHtml(l, i)).join('')}</div>`;
      } else if (!covered) {
        body += '<div class="wg-cell"></div>';
      }
    }
  }

  $('#weekHead').innerHTML = `
    <div class="week-hero">
      <div class="hero-top"><span class="hero-date">第 ${week} 教学周</span>
        <span class="chip chip-week">${formatDate(dateOfWeek(state.termStart, week, 1))} ~ ${formatDate(dateOfWeek(state.termStart, week, 7))}</span>
      </div>
      <div class="hero-chips">
        <span class="chip">本周 ${totalLessons} 节</span>
        <span class="chip">${state.weekFormat === 'classic' ? '经典表格' : '彩色网格'}</span>
        ${state.showAllWeeks ? '<span class="chip chip-warn">未按周次过滤</span>' : ''}
      </div>
    </div>`;

  const gridEl = $('#weekGrid');
  const classicEl = $('#weekClassic');
  const stripEl = $('#weekStrip');
  const bodyEl = $('#weekBody');

  // 手机端不摆 12×5 的大网格，改成「按天切换」的列表，更适合竖屏查看
  if (isMobileMode()) {
    stripEl.hidden = false;
    gridEl.hidden = true;
    classicEl.hidden = true;
    gridEl.innerHTML = '';
    classicEl.innerHTML = '';
    renderWeekMobile(days, byDay);
    return;
  }
  stripEl.hidden = true;
  bodyEl.innerHTML = '';

  const classic = state.weekFormat === 'classic';
  gridEl.hidden = classic;
  classicEl.hidden = !classic;
  if (classic) {
    gridEl.innerHTML = '';
    classicEl.innerHTML = weekClassicHtml(days, byDay);
  } else {
    classicEl.innerHTML = '';
    gridEl.style.setProperty('--days', days.length);
    gridEl.innerHTML = head + body;
    gridEl.classList.toggle('is-empty', totalLessons === 0);
  }
}

/** 手机端周课表：上面一条可横向滑动的「星期条」，下面是当天的课程 */
function renderWeekMobile(days, byDay) {
  if (!days.length) {
    $('#weekStrip').innerHTML = '';
    $('#weekBody').innerHTML = '';
    return;
  }
  if (weekStripDay == null || !days.some((d) => d.day === weekStripDay)) {
    const todayIdx = weekdayIndex(today());
    weekStripDay = days.some((d) => d.day === todayIdx) ? todayIdx : days[0].day;
  }
  $('#weekStrip').innerHTML = days.map((d) => {
    const info = byDay.get(d.day);
    const active = d.day === weekStripDay;
    return `<button type="button" data-strip-day="${d.day}"
      class="${active ? 'active' : ''}${info.isToday ? ' is-today' : ''}"
      style="--i:${d.day}" aria-pressed="${active}">
      <span>${esc(d.name.replace('星期', '周'))}</span>
      <small>${info.date.getMonth() + 1}/${info.date.getDate()}</small>
      <em>${info.lessons.length} 节</em>
    </button>`;
  }).join('');

  const info = byDay.get(weekStripDay);
  $('#weekBody').innerHTML = info.lessons.length
    ? DAY_FORMATS[state.dayFormat || 'card'](info.lessons, info.date)
    : `<div class="empty">
        <div class="empty-emoji">🍖</div>
        <p class="empty-title">肘子大王说：${info.date.getMonth() + 1}月${info.date.getDate()}日 没有课</p>
        <p class="empty-sub">点上面的日期条换一天看看，或回到「今天」视图。</p>
      </div>`;
}

/** 经典表格格式：像教务系统打印出来的那种方格课表 */
function classicCourseHtml(lesson) {
  const { course, slot, time } = lesson;
  return `<div class="wct-course" tabindex="0" style="--hue:${courseHue(course.name)}">
    <span class="wct-name">${esc(course.name)}${course.custom ? '<span class="tag-custom">自建</span>' : ''}</span>
    <span class="wct-meta">📍 ${esc(course.location || '地点待定')}</span>
    <span class="wct-meta">${esc(course.weeks || '')}</span>
    <span class="wct-meta">${esc((course.teachers || '').split(',')[0])} · ${esc(slot.label)} 节</span>
    <div class="wchip-detail">
      <p class="wd-title">${esc(course.name)}</p>
      ${courseDetailHtml(course, [['节次', `${slot.label} 节`], ['时间', `${time.start} – ${time.end}`]])}
    </div>
  </div>`;
}

function weekClassicHtml(days, byDay) {
  const head = `<thead><tr><th class="wct-time">节次 / 时间</th>${days.map((d) => {
    const info = byDay.get(d.day);
    return `<th class="wct-day${info.isToday ? ' is-today' : ''}" data-date="${formatDate(info.date)}" role="button" tabindex="0" title="查看当天详情">
      ${esc(d.name)}<small>${info.date.getMonth() + 1}/${info.date.getDate()} · ${info.lessons.length} 节</small></th>`;
  }).join('')}</tr></thead>`;

  const rows = [];
  for (let p = 1; p <= 12; p++) {
    const time = PERIOD_TIMES[p - 1];
    const tag = breakTagFor(p);
    const timeCell = `<th class="wct-time" scope="row">
      <b>第 ${p} 节</b><small>${time.start}–${time.end}</small>${tag ? `<em>${tag}</em>` : ''}</th>`;
    const cells = days.map((d) => {
      const info = byDay.get(d.day);
      const starting = info.lessons.filter((l) => l.slot.start === p);
      const covered = info.lessons.some((l) => l.slot.start < p && l.slot.end >= p);
      if (covered) return '';
      const cls = `wct-day${info.isToday ? ' is-today' : ''}`;
      if (!starting.length) return `<td class="${cls}"><span class="wct-empty">—</span></td>`;
      const span = Math.max(1, ...starting.map((l) => Math.max(1, (l.slot.end || l.slot.start) - l.slot.start + 1)));
      return `<td class="${cls}" rowspan="${span}">${starting.map(classicCourseHtml).join('')}</td>`;
    }).join('');
    rows.push(`<tr>${timeCell}${cells}</tr>`);
  }
  return `<table class="wct">${head}<tbody>${rows.join('')}</tbody></table>`;
}

function renderHeader() {
  const meta = schedule.meta || {};
  const items = [meta.student && `${meta.student}${meta.studentId ? `（${meta.studentId}）` : ''}`,
    meta.term,
    meta.printedAt && `打印于 ${meta.printedAt}`,
    state.imported ? `已导入 ${state.importedName}` : '内置课表'];
  $('#metaLine').textContent = items.filter(Boolean).join(' · ');
  $('#statLessons').textContent = store.countCourses(schedule);
  $('#statDays').textContent = (schedule.days || []).length;
  $('#statWeek').textContent = Math.max(teachingWeek(selectedDate, state.termStart), 0) || '—';
  $('#statCustom').textContent = (state.custom || []).length;
  $('#importBadge').hidden = !state.imported;
  $('#termStartEcho').textContent = state.termStart;
  $('#showAllWeeks').checked = state.showAllWeeks;
  $('#termStart').value = state.termStart;
  $('#dayFormat').value = state.dayFormat || 'card';
  $('#weekFormat').value = state.weekFormat || 'grid';
  $('#welcomeToggle').checked = state.welcome !== false;
  $('#btnFormat').title = `切换当天视图格式（当前：${DAY_FORMAT_LABELS[state.dayFormat || 'card']}）`;
  renderCustomEcho();
}

// ------------------------------------------------- 自建课程（长期 / 部分时间段）

let editingCourseId = '';

function customList() {
  return (state.custom || []).map(CustomCourses.normalize);
}

function renderCustomEcho() {
  const echo = $('#customEcho');
  if (!echo) return;
  const list = customList();
  echo.textContent = list.length
    ? list.map((c) => `${c.name}（${CustomCourses.summary(c)}）`).join('；')
    : '还没有自建课程。可以添加社团、辅导班、固定自习等课表外的安排。';
}

function fillCourseFormOptions() {
  const options = Array.from({ length: MAX_PERIODS }, (_, i) => {
    const p = i + 1;
    const t = periodTime(p);
    return `<option value="${p}">第 ${p} 节（${t.start}–${t.end}）</option>`;
  }).join('');
  $('#cStart').innerHTML = options;
  $('#cEnd').innerHTML = options;
  $('#cDays').innerHTML = [1, 2, 3, 4, 5, 6, 7].map((d) => `<label class="day-chip">
    <input type="checkbox" value="${d}"><span>周${'一二三四五六日'[d - 1]}</span>
  </label>`).join('');
}

function resetCourseForm() {
  editingCourseId = '';
  $('#courseDialogTitle').textContent = '添加自建课程';
  $('#cSubmit').textContent = '添加课程';
  $('#cName').value = '';
  $('#cPlace').value = '';
  $('#cTeacher').value = '';
  $('#cCampus').value = '';
  $('#cNote').value = '';
  $('#cWeeks').value = '';
  $('#cFrom').value = '';
  $('#cTo').value = '';
  $$('#cDays input').forEach((box, idx) => { box.checked = idx === weekdayIndex(today()) - 1; });
  $('#cStart').value = '1';
  $('#cEnd').value = '2';
  const always = $('input[name="cMode"][value="always"]');
  if (always) always.checked = true;
  $('#cPartial').hidden = true;
}

function fillCourseForm(raw) {
  const e = CustomCourses.normalize(raw);
  editingCourseId = e.id;
  $('#courseDialogTitle').textContent = `编辑「${e.name}」`;
  $('#cSubmit').textContent = '保存修改';
  $('#cName').value = e.name;
  $('#cPlace').value = e.location;
  $('#cTeacher').value = e.teachers;
  $('#cCampus').value = e.campus;
  $('#cNote').value = e.note;
  $('#cWeeks').value = CustomCourses.weeksLabel(e.weekRanges).replace(/周/g, '');
  $('#cFrom').value = e.dateFrom;
  $('#cTo').value = e.dateTo;
  $$('#cDays input').forEach((box) => { box.checked = e.days.includes(Number(box.value)); });
  $('#cStart').value = String(e.start);
  $('#cEnd').value = String(e.end);
  const partial = !CustomCourses.isAlways(e);
  const radio = $(`input[name="cMode"][value="${partial ? 'partial' : 'always'}"]`);
  if (radio) radio.checked = true;
  $('#cPartial').hidden = !partial;
}

/** 「加入方式」当前是否选的是「长期加入」 */
function modeIsAlways() {
  const checked = $('input[name="cMode"]:checked');
  return !checked || checked.value === 'always';
}

function formToEntry() {
  const mode = modeIsAlways() ? 'always' : 'partial';
  const days = $$('#cDays input:checked').map((box) => Number(box.value));
  const start = Number($('#cStart').value);
  const end = Number($('#cEnd').value);
  return CustomCourses.normalize({
    id: editingCourseId || undefined,
    name: $('#cName').value,
    location: $('#cPlace').value,
    teachers: $('#cTeacher').value,
    campus: $('#cCampus').value,
    note: $('#cNote').value,
    days,
    start: Math.min(start, end),
    end: Math.max(start, end),
    weeksText: mode === 'partial' ? $('#cWeeks').value : '',
    dateFrom: mode === 'partial' ? $('#cFrom').value : '',
    dateTo: mode === 'partial' ? $('#cTo').value : ''
  });
}

function renderCustomListDialog() {
  const list = customList();
  $('#customCount').textContent = list.length ? `共 ${list.length} 条` : '';
  $('#customList').innerHTML = list.length
    ? list.map((c) => `<li data-id="${esc(c.id)}">
        <div class="cl-main">
          <span class="cl-name">${esc(c.name)}</span>
          <span class="cl-meta">${esc(CustomCourses.summary(c))}</span>
          ${c.location ? `<span class="cl-meta">📍 ${esc(c.location)}</span>` : ''}
          ${c.note ? `<span class="cl-meta">${esc(c.note)}</span>` : ''}
        </div>
        <div class="cl-actions">
          <button type="button" class="btn ghost small" data-course-edit="${esc(c.id)}">编辑</button>
          <button type="button" class="btn ghost small danger" data-course-del="${esc(c.id)}">删除</button>
        </div>
      </li>`).join('')
    : '<li class="cl-empty">还没有添加自建课程</li>';
}

function openCourseDialog(entry) {
  if (entry) fillCourseForm(entry);
  else resetCourseForm();
  renderCustomListDialog();
  const dialog = $('#courseDialog');
  if (!dialog.open) dialog.showModal();
  $('#cName').focus();
}

function saveCourseFromForm() {
  const entry = formToEntry();
  if (!entry.name) {
    toast('请先填写课程名称', 'warn');
    $('#cName').focus();
    return;
  }
  if (!state.custom) state.custom = [];
  if (editingCourseId) {
    const idx = state.custom.findIndex((c) => c.id === editingCourseId);
    if (idx >= 0) state.custom[idx] = { ...state.custom[idx], ...entry };
    toast(`已更新「${entry.name}」：${CustomCourses.summary(entry)}`);
  } else {
    state.custom.push(entry);
    toast(`已添加「${entry.name}」：${CustomCourses.summary(entry)}`);
  }
  store.save(state);
  resetCourseForm();
  renderCustomListDialog();
  renderAll();
}

function removeCustomCourse(id) {
  const target = (state.custom || []).find((c) => c.id === id);
  state.custom = (state.custom || []).filter((c) => c.id !== id);
  store.save(state);
  if (editingCourseId === id) resetCourseForm();
  renderCustomListDialog();
  renderAll();
  if (target) toast(`已删除「${target.name}」`);
}

function applyView() {
  $('#dayView').hidden = state.view !== 'day';
  $('#weekView').hidden = state.view !== 'week';
  $$('.view-switch button').forEach((b) => b.classList.toggle('active', b.dataset.view === state.view));
  $$('#bottomNav button[data-view]').forEach((b) => b.classList.toggle('active', b.dataset.view === state.view));
  if (state.view === 'week') renderWeek();
  else renderDay();
  $('#othersSlot').innerHTML = otherCoursesHtml();
}

function renderAll() {
  syncHash();
  renderHeader();
  applyView();
}

/** 支持 #week / #day/2026-09-14 这样的深链 */
function applyHash() {
  const m = /^(day|week)(?:\/(\d{4}-\d{2}-\d{2}))?$/.exec((location.hash || '').replace(/^#/, ''));
  if (!m) return false;
  state.view = m[1];
  if (m[2]) selectedDate = parseDate(m[2]);
  return true;
}

function syncHash() {
  const hash = state.view === 'week' ? '#week' : `#day/${formatDate(selectedDate)}`;
  if (location.hash !== hash) {
    history.replaceState(null, '', `${location.pathname}${hash}`);
  }
}

function applyTheme() {
  const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
  const dark = state.theme ? state.theme === 'dark' : prefersDark;
  document.documentElement.dataset.theme = dark ? 'dark' : 'light';
  $('#btnTheme').textContent = dark ? '☀️' : '🌙';
  $('#btnTheme').title = dark ? '切换到浅色' : '切换到深色';
}

let toastTimer = null;
function toast(message, kind = 'ok') {
  const box = $('#toast');
  box.textContent = message;
  box.dataset.kind = kind;
  box.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => box.classList.remove('show'), 4200);
}

async function importPdf(file) {
  if (!file) return;
  if (!/\.pdf$/i.test(file.name)) {
    toast('请选择 PDF 文件（教务系统导出的课表）', 'warn');
    return;
  }
  toast(`正在解析 ${file.name} …`, 'info');
  try {
    const buffer = await file.arrayBuffer();
    const result = await parseTimetablePdf(new Uint8Array(buffer), {
      source: file.name,
      importedAt: new Date().toISOString()
    });
    const count = store.countCourses(result);
    if (!count) {
      toast(`没能从 ${file.name} 里解析出课程${result.warnings.length ? '：' + result.warnings[0] : ''}`, 'warn');
      return;
    }
    state.imported = result;
    state.importedName = file.name;
    store.save(state);
    schedule = result;
    selectedDate = today();
    renderAll();
    toast(`已导入 ${file.name}：${result.days.length} 天、${count} 门次课${result.others.length ? `、${result.others.length} 条其他课程` : ''}`);
  } catch (err) {
    console.error(err);
    toast(`解析失败：${err.message}`, 'warn');
  }
}

function restoreBuiltin() {
  store.reset(state);
  schedule = store.currentSchedule(state);
  selectedDate = today();
  renderAll();
  toast('已恢复内置课表');
}

const stepDay = (delta) => {
  selectedDate = addDays(selectedDate, delta);
  if (state.view !== 'day') {
    state.view = 'day';
    store.save(state);
  }
  renderAll();
};

/** 用打印日期推算开学日：把打印那一周当作第 2 周 */
function guessTermStart() {
  const printed = (schedule.meta || {}).printedAt;
  if (!printed) {
    toast('当前课表没有「打印时间」信息，无法推算', 'warn');
    return;
  }
  const monday = startOfWeek(parseDate(printed));
  state.termStart = formatDate(addDays(monday, -7));
  store.save(state);
  renderAll();
  toast(`已按打印日期推算：${state.termStart} 为第 1 周周一`);
}

// ------------------------------------------- 肘子大王 / 欢迎动画 / 格式切换

const DH_TIPS = [
  '肘子大王提醒：第 3 节 10:20 才开始，早八后可以先喘口气 🍖',
  '肘子大王说：课间只有 10 分钟，跑教室要趁早 🏃',
  '肘子大王名言：午休 12:00–14:00，睡觉也是正事 😴',
  '肘子大王建议：鼠标悬停课程卡片，能看到全部信息 👀',
  '肘子大王悄悄说：顶部 🎨 可以换课表格式',
  '肘子大王今天也想翘课，但它不会点名 🍗',
  '肘子大王提醒：最后一节 20:20 开始，记得先吃饭'
];

function showDhTip() {
  toast(DH_TIPS[Math.floor(Math.random() * DH_TIPS.length)], 'dh');
}

let splashTimer = null;
function hideSplash(el = $('#splash')) {
  if (!el || el.hidden) return;
  clearTimeout(splashTimer);
  el.classList.add('is-hiding');
  setTimeout(() => {
    el.hidden = true;
    el.classList.remove('is-hiding');
  }, 580);
}
function scheduleSplashHide(el, delay) {
  clearTimeout(splashTimer);
  splashTimer = setTimeout(() => hideSplash(el), delay);
}
/** 打开时先让肘子大王出场 1 秒；关掉过就直接不显示 */
function initSplash() {
  const el = $('#splash');
  if (!el) return;
  const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (state.welcome === false || reduced || document.documentElement.dataset.welcome === 'off') {
    el.hidden = true;
    return;
  }
  scheduleSplashHide(el, 1000);
  el.addEventListener('click', () => hideSplash(el));
  const never = $('#splashNever');
  if (never) {
    never.addEventListener('click', (e) => {
      e.stopPropagation();
      state.welcome = false;
      store.save(state);
      hideSplash(el);
      const box = $('#welcomeToggle');
      if (box) box.checked = false;
      toast('好嘞，以后打开不再显示欢迎动画（设置里可重新打开）');
    });
  }
  window.addEventListener('keydown', () => hideSplash(el), { once: true });
}
function previewSplash() {
  const el = $('#splash');
  if (!el) return;
  el.hidden = false;
  el.classList.remove('is-hiding');
  void el.offsetWidth;
  scheduleSplashHide(el, 1000);
}

function cycleDayFormat() {
  const order = ['card', 'compact', 'timeline'];
  const next = order[(order.indexOf(state.dayFormat || 'card') + 1) % order.length];
  state.dayFormat = next;
  store.save(state);
  renderAll();
  toast(`当天视图格式：${DAY_FORMAT_LABELS[next]}`);
}

function wireEvents() {
  document.addEventListener('click', (e) => {
    const viewBtn = e.target.closest('[data-view]');
    if (viewBtn) {
      state.view = viewBtn.dataset.view;
      store.save(state);
      applyView();
      return;
    }
    const switchBtn = e.target.closest('[data-switch-view]');
    if (switchBtn) {
      state.view = switchBtn.dataset.switchView;
      store.save(state);
      applyView();
      return;
    }
    if (e.target.closest('[data-add-course]')) {
      openCourseDialog();
      return;
    }
    const editBtn = e.target.closest('[data-course-edit]');
    if (editBtn) {
      openCourseDialog((state.custom || []).find((c) => c.id === editBtn.dataset.courseEdit));
      return;
    }
    const delBtn = e.target.closest('[data-course-del]');
    if (delBtn) {
      removeCustomCourse(delBtn.dataset.courseDel);
      return;
    }
    const stepBtn = e.target.closest('[data-day-step]');
    if (stepBtn) {
      stepDay(Number(stepBtn.dataset.dayStep));
      return;
    }
    const stripBtn = e.target.closest('[data-strip-day]');
    if (stripBtn) {
      weekStripDay = Number(stripBtn.dataset.stripDay);
      const info = (schedule.days || []).find((d) => d.day === weekStripDay);
      if (info) {
        const date = dateOfWeek(state.termStart, Math.max(teachingWeek(selectedDate, state.termStart), 1), weekStripDay);
        selectedDate = date;
      }
      renderWeek();
      // 同步到底部导航/顶部标签的高亮
      $$('#bottomNav button[data-view]').forEach((b) => b.classList.toggle('active', b.dataset.view === 'week'));
      return;
    }
    if (e.target.closest('[data-goto-today]')) {
      selectedDate = today();
      renderAll();
      return;
    }
    const dayHead = e.target.closest('[data-date]');
    if (dayHead && dayHead.dataset.date) {
      selectedDate = parseDate(dayHead.dataset.date);
      state.view = 'day';
      store.save(state);
      renderAll();
    }
  });

  document.addEventListener('keydown', (e) => {
    if (e.target.matches('input, textarea')) return;
    if (e.key === 'ArrowLeft') stepDay(-1);
    else if (e.key === 'ArrowRight') stepDay(1);
    else if (e.key === 'Enter' && e.target.dataset && e.target.dataset.date) e.target.click();
  });

  $('#btnTheme').addEventListener('click', () => {
    const dark = document.documentElement.dataset.theme === 'dark';
    state.theme = dark ? 'light' : 'dark';
    store.save(state);
    applyTheme();
  });

  $('#btnSettings').addEventListener('click', () => $('#settingsDialog').showModal());
  $('#btnCloseSettings').addEventListener('click', () => $('#settingsDialog').close());

  // 肘子大王 / 格式切换 / 欢迎动画
  $('#dhButton').addEventListener('click', showDhTip);
  $('#btnFormat').addEventListener('click', cycleDayFormat);
  $('#dayFormat').addEventListener('change', (e) => {
    state.dayFormat = e.target.value;
    store.save(state);
    renderAll();
    toast(`当天视图格式：${DAY_FORMAT_LABELS[state.dayFormat] || ''}`);
  });
  $('#weekFormat').addEventListener('change', (e) => {
    state.weekFormat = e.target.value;
    store.save(state);
    renderAll();
    toast(`周课表格式：${state.weekFormat === 'classic' ? '经典表格' : '彩色网格'}`);
  });
  $('#welcomeToggle').addEventListener('change', (e) => {
    state.welcome = e.target.checked;
    store.save(state);
    if (state.welcome) {
      delete document.documentElement.dataset.welcome;
      previewSplash();
      toast('已开启欢迎动画：肘子大王每次都会出场 1 秒');
    } else {
      document.documentElement.dataset.welcome = 'off';
      hideSplash();
      toast('已关闭欢迎动画，下次打开不会再见');
    }
  });

  // 自建课程
  $('#btnAddCourse').addEventListener('click', () => openCourseDialog());
  $('#btnManageCustom').addEventListener('click', () => {
    $('#settingsDialog').close();
    openCourseDialog();
  });
  $('#cClose').addEventListener('click', () => $('#courseDialog').close());
  $('#cClear').addEventListener('click', resetCourseForm);
  $('#courseForm').addEventListener('submit', (e) => {
    e.preventDefault();
    saveCourseFromForm();
  });
  $$('input[name="cMode"]').forEach((radio) => radio.addEventListener('change', () => {
    $('#cPartial').hidden = modeIsAlways();
  }));
  [$('#settingsDialog'), $('#courseDialog')].forEach((dialog) => {
    dialog.addEventListener('click', (e) => {
      if (e.target === dialog) dialog.close();
    });
  });
  window.addEventListener('hashchange', () => {
    if (applyHash()) renderAll();
  });

  // 手机端：点一下卡片就展开 / 收起全部信息（触屏没有 hover）
  document.addEventListener('click', (e) => {
    const card = e.target.closest('.lesson-card, .cct-row, .tl-block, .wchip, .wct-course');
    const touchy = isMobileMode() || (navigator.maxTouchPoints || 0) > 0;
    if (!touchy) return;
    if (e.target.closest('a, button')) return;
    $$('.is-open').forEach((el) => { if (el !== card) el.classList.remove('is-open'); });
    if (card) card.classList.toggle('is-open');
  });

  // 界面端切换
  $('#btnDevice').addEventListener('click', toggleDeviceMode);
  $('#deviceMode').addEventListener('change', (e) => setDeviceMode(e.target.value));
  $('#navAddCourse').addEventListener('click', () => openCourseDialog());
  $('#navSettings').addEventListener('click', () => $('#settingsDialog').showModal());

  let resizeTimer = null;
  const onViewportChanged = () => {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(() => {
      if ((state.device || 'auto') === 'auto') {
        const mode = Device.effective(state.device);
        if (mode !== document.documentElement.dataset.device) {
          applyDeviceMode();
          weekStripDay = null;
          renderAll();
          return;
        }
      }
      Device.apply(Device.effective(state.device));
    }, 180);
  };
  window.addEventListener('resize', onViewportChanged);
  window.addEventListener('orientationchange', onViewportChanged);

  const pick = () => $('#fileInput').click();
  $('#btnImport').addEventListener('click', pick);
  $('#btnImportDialog').addEventListener('click', pick);
  $('#fileInput').addEventListener('change', (e) => {
    importPdf(e.target.files[0]);
    e.target.value = '';
  });

  $('#termStart').addEventListener('change', (e) => {
    if (!e.target.value) return;
    state.termStart = e.target.value;
    store.save(state);
    renderAll();
  });
  $('#btnGuessTerm').addEventListener('click', guessTermStart);
  $('#showAllWeeks').addEventListener('change', (e) => {
    state.showAllWeeks = e.target.checked;
    store.save(state);
    renderAll();
  });
  $('#btnReset').addEventListener('click', restoreBuiltin);
  $('#btnExport').addEventListener('click', () => {
    const name = `${(schedule.meta || {}).student || '课表'}-${(schedule.meta || {}).term || 'schedule'}.json`;
    store.downloadJson({ ...schedule, custom: state.custom || [] }, name.replace(/\s+/g, ''));
    toast('已导出课表 JSON（含自建课程）');
  });

  document.addEventListener('dragover', (e) => {
    e.preventDefault();
    document.body.classList.add('is-dragging');
  });
  document.addEventListener('dragleave', () => document.body.classList.remove('is-dragging'));
  document.addEventListener('drop', (e) => {
    e.preventDefault();
    document.body.classList.remove('is-dragging');
    const file = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
    if (file) importPdf(file);
  });
}

function init() {
  applyTheme();
  applyDeviceMode();
  fillCourseFormOptions();
  resetCourseForm();
  renderCustomListDialog();
  applyHash();
  wireEvents();
  renderAll();
  setInterval(() => {
    if (state.view === 'day') renderDay();
  }, 30000);
  if (!(schedule.days || []).length) {
    toast('还没有课表数据，点右上角「导入 PDF」选择教务系统导出的课表', 'warn');
  }
  initSplash();
}

init();

// 方便在控制台里调试
window.courseSchedule = {
  state,
  get schedule() { return schedule; },
  renderAll,
  importPdf,
  openCourseDialog,
  saveCourseFromForm,
  removeCustomCourse,
  toggleDeviceMode,
  setDeviceMode
};

})();
