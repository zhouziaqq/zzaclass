/**
 * custom-courses.js —— 自主添加的课程（自建课程）
 *
 * 自建课程保存在浏览器本地（localStorage，键见 store.js），与 PDF 导入的课表互不影响：
 * 导入新学期课表时自建课程不会被清掉。
 *
 * 一条自建课程的数据结构：
 * {
 *   id: 'c...',              // 唯一 id（编辑/删除用）
 *   name: '数学建模讨论',     // 课程名称（必填）
 *   location: '笃行2-305',   // 地点
 *   teachers: '张三',        // 教师
 *   campus: '旗山校区',      // 校区
 *   note: '社团课',          // 备注
 *   days: [1, 3],            // 星期几：1=周一 … 7=周日（可多选）
 *   start: 5, end: 6,        // 节次（含）
 *   weekRanges: [[3, 8]],    // 部分时间段：教学周；空数组 = 不限
 *   dateFrom: '2026-09-14',  // 部分时间段：起始日期；'' = 不限
 *   dateTo: '2026-10-30',    // 部分时间段：结束日期；'' = 不限
 *   createdAt: 1699999999999
 * }
 */
(function (global) {
'use strict';

const DAY_NAMES = ['一', '二', '三', '四', '五', '六', '日'];

const deps = () => ({
  DateUtils: global.DateUtils,
  TimetablePdf: global.TimetablePdf
});

function uid() {
  return 'c' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
}

/** 宽容地解析「3-8,10」「3~5周,8周」这类周次输入 */
function parseWeeks(text) {
  const out = [];
  const re = /(\d{1,2})\s*[-~到至]\s*(\d{1,2})|(\d{1,2})/g;
  let m;
  while ((m = re.exec(String(text == null ? '' : text)))) {
    if (m[1] !== undefined) out.push([Math.min(+m[1], +m[2]), Math.max(+m[1], +m[2])]);
    else out.push([+m[3], +m[3]]);
  }
  const valid = out.filter(([a, b]) => a >= 1 && b <= 60);
  valid.sort((x, y) => x[0] - y[0]);
  return valid;
}

function weeksLabel(ranges) {
  return (ranges || []).map(([a, b]) => (a === b ? `${a}周` : `${a}-${b}周`)).join('、');
}

/** 节次标签：5-6 / 3（与 PDF 课表里的 "1-2"、"3-4" 保持一致，便于合并到同一格） */
function periodLabel(start, end) {
  const s = Number(start) || 1;
  const e = Math.max(s, Number(end) || s);
  return s === e ? String(s) : `${s}-${e}`;
}

function dayNames(days) {
  return (days || []).slice().sort((a, b) => a - b).map((d) => `周${DAY_NAMES[d - 1]}`).join(' ');
}

/** 补齐字段，保证后续代码拿到统一结构 */
function normalize(entry) {
  const start = Math.min(12, Math.max(1, Number(entry.start) || 1));
  const end = Math.min(12, Math.max(start, Number(entry.end) || start));
  const weekRanges = entry.weekRanges && entry.weekRanges.length
    ? entry.weekRanges
    : parseWeeks(entry.weeksText || '');
  const days = (entry.days || []).map(Number).filter((d) => d >= 1 && d <= 7);
  return {
    id: entry.id || uid(),
    name: (entry.name || '').trim(),
    location: (entry.location || '').trim(),
    teachers: (entry.teachers || '').trim(),
    campus: (entry.campus || '').trim(),
    note: (entry.note || '').trim(),
    days: days.length ? days : [1],
    start,
    end,
    weekRanges,
    dateFrom: entry.dateFrom || '',
    dateTo: entry.dateTo || '',
    createdAt: entry.createdAt || Date.now()
  };
}

/** 是否「长期加入」：没有任何周次/日期限制 */
function isAlways(entry) {
  return !entry.weekRanges.length && !entry.dateFrom && !entry.dateTo;
}

/** 生成展示用的有效期文字 */
function validLabel(entry) {
  const parts = [];
  if (entry.weekRanges.length) parts.push(weeksLabel(entry.weekRanges));
  if (entry.dateFrom && entry.dateTo) parts.push(`${entry.dateFrom} ~ ${entry.dateTo}`);
  else if (entry.dateFrom) parts.push(`${entry.dateFrom} 起`);
  else if (entry.dateTo) parts.push(`至 ${entry.dateTo}`);
  return parts.length ? parts.join(' / ') : '长期（每周）';
}

/** 自建课程 -> 与 PDF 课程同构的对象，方便复用同一套渲染 */
function toCourse(entry) {
  return {
    name: entry.name,
    weeks: validLabel(entry),
    weekRanges: entry.weekRanges,
    campus: entry.campus,
    location: entry.location,
    teachers: entry.teachers,
    className: '',
    classInfo: '',
    note: entry.note,
    hours: '',
    custom: true,
    customId: entry.id
  };
}

/** 这条自建课程在指定日期、指定教学周是否要显示 */
function matches(entry, date, week, opts = {}) {
  const { DateUtils } = deps();
  if (!entry || !entry.days.includes(DateUtils.weekdayIndex(date))) return false;
  const day = DateUtils.formatDate(date);
  if (entry.dateFrom && day < entry.dateFrom) return false;
  if (entry.dateTo && day > entry.dateTo) return false;
  if (!opts.showAllWeeks && week >= 1 && entry.weekRanges.length
    && !deps().TimetablePdf.inWeeks(entry.weekRanges, week)) return false;
  return true;
}

/** 取出某天要显示的自建课程（按节次归组，和 PDF 课表同样的形状） */
function coursesForDate(entries, date, week, opts = {}) {
  const out = [];
  for (const raw of entries || []) {
    const entry = normalize(raw);
    if (!entry.name) continue;
    if (!matches(entry, date, week, opts)) continue;
    out.push({
      entry,
      course: toCourse(entry),
      slot: {
        label: periodLabel(entry.start, entry.end),
        start: entry.start,
        end: entry.end,
        courses: []
      }
    });
  }
  out.sort((a, b) => a.slot.start - b.slot.start);
  return out;
}

/** 汇总信息，用于设置面板展示 */
function summary(entry) {
  return `${dayNames(entry.days)} · ${periodLabel(entry.start, entry.end)} 节 · ${validLabel(entry)}`;
}

global.CustomCourses = {
  uid,
  parseWeeks,
  weeksLabel,
  periodLabel,
  dayNames,
  normalize,
  isAlways,
  validLabel,
  toCourse,
  matches,
  coursesForDate,
  summary
};
})(typeof window !== 'undefined' ? window : globalThis);
