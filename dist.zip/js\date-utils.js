/**
 * date-utils.js —— 教学周相关的日期计算（全部按本地时间，周一为一周第一天）
 */

(function (global) {
'use strict';

const WEEKDAY_NAMES = ['星期一', '星期二', '星期三', '星期四', '星期五', '星期六', '星期日'];

function parseDate(value) {
  if (value instanceof Date) return new Date(value.getFullYear(), value.getMonth(), value.getDate());
  const [y, m, d] = String(value).split('-').map(Number);
  return new Date(y, (m || 1) - 1, d || 1);
}

function formatDate(date) {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
}

function addDays(date, days) {
  const d = new Date(date.getFullYear(), date.getMonth(), date.getDate());
  d.setDate(d.getDate() + days);
  return d;
}

function isSameDay(a, b) {
  return a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();
}

function today() {
  const now = new Date();
  return new Date(now.getFullYear(), now.getMonth(), now.getDate());
}

/** 周一 = 1 ... 周日 = 7 */
function weekdayIndex(date) {
  const wd = date.getDay();
  return wd === 0 ? 7 : wd;
}

/** 取所在周的周一 */
function startOfWeek(date) {
  return addDays(date, 1 - weekdayIndex(date));
}

/** 教学周（第几周，1 起）；早于开学周返回 <= 0 */
function teachingWeek(date, termStart) {
  const start = startOfWeek(parseDate(termStart));
  const diffDays = Math.round((parseDate(date) - start) / 86400000);
  return Math.floor(diffDays / 7) + 1;
}

/** 「9月13日 星期日」 */
function humanDate(date) {
  return `${date.getMonth() + 1}月${date.getDate()}日 ${WEEKDAY_NAMES[weekdayIndex(date) - 1]}`;
}

/** 第 N 周 -> 该周周一的日期 */
function dateOfWeek(termStart, week, dayIndex = 1) {
  return addDays(startOfWeek(parseDate(termStart)), (week - 1) * 7 + (dayIndex - 1));
}

  global.DateUtils = {
    WEEKDAY_NAMES,
    parseDate,
    formatDate,
    addDays,
    isSameDay,
    today,
    weekdayIndex,
    startOfWeek,
    teachingWeek,
    humanDate,
    dateOfWeek
  };
})(typeof window !== 'undefined' ? window : globalThis);
