/**
 * device.js —— 电脑端 / 手机端的识别与切换
 *
 * 判定顺序（auto 模式）：
 *   1. UA 里出现 Android / iPhone / 微信 / 鸿蒙 等关键字 -> 手机端；
 *   2. 窗口宽度 <= 820px -> 手机端；
 *   3. 主指针是 coarse（触屏为主）且宽度 <= 1180px（iPad 之类）-> 手机端；
 *   4. 其余 -> 电脑端。
 *
 * 用户可以在界面上一键切到「手机版 / 电脑版」，选择会存在本地，
 * 所以 detect() 是纯函数（传入环境信息），方便在 Node 里做自检。
 */
(function (global) {
'use strict';

const MOBILE_UA_RE = /Android|iPhone|iPod|iPad|Windows Phone|Mobile|HarmonyOS|HUAWEI|Xiaomi|Redmi|miui|MicroMessenger|QQ\/|AlipayClient|BlackBerry|Opera Mini|IEMobile/i;

const NARROW_WIDTH = 820;
const TOUCH_TABLET_WIDTH = 1180;

/**
 * @param {{ua?:string, width?:number, coarse?:boolean}} env
 * @returns {'mobile'|'desktop'}
 */
function detect(env = {}) {
  const ua = env.ua == null ? '' : String(env.ua);
  const width = Number(env.width) || 0;
  const coarse = !!env.coarse;

  if (MOBILE_UA_RE.test(ua)) return 'mobile';
  if (width && width <= NARROW_WIDTH) return 'mobile';
  if (coarse && width && width <= TOUCH_TABLET_WIDTH) return 'mobile';
  return 'desktop';
}

/** 读取当前真实环境 */
function readEnv() {
  const nav = global.navigator || {};
  const width = global.innerWidth || (global.document && global.document.documentElement.clientWidth) || 1024;
  let coarse = false;
  try {
    coarse = !!(global.matchMedia && global.matchMedia('(pointer: coarse)').matches);
  } catch (err) { /* 忽略 */ }
  const touch = (nav.maxTouchPoints || 0) > 0 || 'ontouchstart' in global;
  return { ua: nav.userAgent || '', width, coarse: coarse || (touch && !coarse && width <= NARROW_WIDTH) };
}

/** auto 模式下当前应该用哪种端 */
function effective(preference, env = readEnv()) {
  if (preference === 'mobile' || preference === 'desktop') return preference;
  return detect(env);
}

/** 把结果写到 <html data-device="...">，并同步相关按钮文案 */
function apply(mode) {
  const doc = global.document;
  if (!doc) return mode;
  doc.documentElement.dataset.device = mode;
  if (doc.body) doc.body.classList.toggle('is-mobile', mode === 'mobile');
  if (global.Times && doc.documentElement.style) {
    // 手机端地址栏会吃掉高度，用 --vh 修补 100vh 类写法
    doc.documentElement.style.setProperty('--vh', `${(global.innerHeight || 0) / 100}px`);
  }
  return mode;
}

global.Device = {
  MOBILE_UA_RE,
  NARROW_WIDTH,
  TOUCH_TABLET_WIDTH,
  detect,
  readEnv,
  effective,
  apply,
  label: (mode) => (mode === 'mobile' ? '手机版' : '电脑版')
};
})(typeof window !== 'undefined' ? window : globalThis);
