/**
 * pdf-parser.js —— 零依赖的课表 PDF 解析器
 *
 * 目标文件是学校教务系统（iText + STSong-Light / UniGB-UCS2-H）导出的
 * 「学生课表」PDF。解析流程：
 *   1. 按对象切分 PDF，取出 FlateDecode 内容流（浏览器用 DecompressionStream 解压）；
 *   2. 解释内容流里的 BT / Tm / Td / Tj / re / cm / q / Q 等运算符，得到带坐标的文字与表格线；
 *   3. 用表格线还原「星期(行分组) → 节次(单元格) → 课程(行)」三级结构；
 *   4. 把课程明细行按分隔符拆成 周数 / 校区 / 地点 / 教师 / 教学班 / 学时 等字段。
 *
 * 内容流最外层带一个只用于把纵向页面旋正的 cm，解析时会用它的逆矩阵还原成
 * 「用户看到的横向页面坐标」，所以结果里 x 向右、y 向上、单位接近 pt。
 */

(function (global) {
'use strict';

// 字面字符串 | 十六进制字符串 | 数组 | 名字对象 | 数字 | 运算符 | 注释
const TOKEN_RE = /(\((?:[^\\()]|\\.|\((?:[^\\()]|\\.)*\))*\))|(<[0-9A-Fa-f\s]*>)|(\[|\])|(\/[^\s\/\[\]<>(){}]+)|([-+]?(?:\d+\.?\d*|\.\d+))|([A-Za-z'"*][A-Za-z0-9'"*]*)|(%[^\r\n]*)/g;

const TWO_BYTE_ENCODING_RE = /UniGB-UCS2-H|UniCNS-UCS2-H|UniJIS-UCS2-H|UniKS-UCS2-H|Identity-H/;

const PDF_ESCAPES = { n: '\n', r: '\r', t: '\t', b: '\b', f: '\f', '(': '(', ')': ')', '\\': '\\' };

/** Uint8Array -> 每字符等于一字节的字符串（便于按字节偏移切分 PDF 结构） */
function latin1(bytes) {
  let out = '';
  const CHUNK = 0x8000;
  for (let i = 0; i < bytes.length; i += CHUNK) {
    out += String.fromCharCode.apply(null, bytes.subarray(i, Math.min(i + CHUNK, bytes.length)));
  }
  return out;
}

/** 字符串 -> Uint8Array（仅低 8 位有效） */
function bytesFromLatin1(str) {
  const out = new Uint8Array(str.length);
  for (let i = 0; i < str.length; i++) out[i] = str.charCodeAt(i) & 0xff;
  return out;
}

/** zlib(deflate) 解压；浏览器与 Node 18+ 都自带 DecompressionStream */
async function inflate(bytes) {
  if (typeof DecompressionStream === 'undefined') {
    throw new Error('当前环境不支持 DecompressionStream，请使用新版 Chrome / Edge / Firefox 打开本页面。');
  }
  const stream = new Blob([bytes]).stream().pipeThrough(new DecompressionStream('deflate'));
  return new Uint8Array(await new Response(stream).arrayBuffer());
}

/** 把 PDF 里所有对象按出现顺序切出来：{ num, dict, raw } */
function splitObjects(bin) {
  const objs = [];
  const re = /(\d+)\s+\d+\s+obj\b/g;
  let m;
  while ((m = re.exec(bin))) {
    const end = bin.indexOf('endobj', m.index);
    if (end < 0) continue;
    const body = bin.slice(m.index, end);
    objs.push({ num: Number(m[1]), body });
  }
  return objs;
}

/** 取出一个对象里 stream 与 endstream 之间的原始字节（按 /Length 精确截断） */
function objectStream(obj) {
  const start = obj.body.indexOf('stream');
  if (start < 0) return null;
  let dataStart = start + 'stream'.length;
  if (obj.body[dataStart] === '\r') dataStart++;
  if (obj.body[dataStart] === '\n') dataStart++;
  const end = obj.body.indexOf('endstream', dataStart);
  if (end < 0) return null;
  const dict = obj.body.slice(0, start);
  let data = obj.body.slice(dataStart, end);
  const lm = /\/Length\s+(\d+)(?!\s+\d+\s+R)/.exec(dict);
  if (lm) {
    const len = Number(lm[1]);
    if (len > 0 && len <= data.length) data = data.slice(0, len);
  } else {
    data = data.replace(/[\r\n]+$/, '');
  }
  return { dict, data };
}

/** 逐页取出内容流（已解压） */
async function contentStreams(bytes) {
  const bin = latin1(bytes);
  const twoByte = TWO_BYTE_ENCODING_RE.test(bin);
  const streams = [];
  for (const obj of splitObjects(bin)) {
    const st = objectStream(obj);
    if (!st) continue;
    let data = bytesFromLatin1(st.data);
    if (/FlateDecode/.test(st.dict)) {
      try {
        data = await inflate(data);
      } catch (err) {
        continue; // 解压失败的对象直接跳过（例如内嵌字体）
      }
    }
    const text = latin1(data);
    if (!/\bBT\b/.test(text) || !/\bre\b/.test(text)) continue; // 只关心页面内容流
    streams.push({ page: streams.length + 1, text, twoByte });
  }
  return streams;
}

// ---------------------------------------------------------------- 内容流解释

function mul(a, b) {
  return [
    a[0] * b[0] + a[1] * b[2],
    a[0] * b[1] + a[1] * b[3],
    a[2] * b[0] + a[3] * b[2],
    a[2] * b[1] + a[3] * b[3],
    a[4] * b[0] + a[5] * b[2] + b[4],
    a[4] * b[1] + a[5] * b[3] + b[5]
  ];
}

function apply(m, x, y) {
  return [m[0] * x + m[2] * y + m[4], m[1] * x + m[3] * y + m[5]];
}

function invert(m) {
  const [a, b, c, d, e, f] = m;
  const det = a * d - b * c;
  return [d / det, -b / det, -c / det, a / det, (c * f - d * e) / det, (b * e - a * f) / det];
}

function unescapeLiteral(raw) {
  let out = '';
  for (let i = 0; i < raw.length; i++) {
    const ch = raw[i];
    if (ch !== '\\') {
      out += ch;
      continue;
    }
    const next = raw[i + 1];
    if (Object.prototype.hasOwnProperty.call(PDF_ESCAPES, next)) {
      out += PDF_ESCAPES[next];
      i++;
    } else if (next >= '0' && next <= '7') {
      const m = /^[0-7]{1,3}/.exec(raw.slice(i + 1));
      out += String.fromCharCode(parseInt(m[0], 8) & 0xff);
      i += m[0].length;
    } else if (next === '\n' || next === '\r') {
      i++;
    } else {
      out += next;
      i++;
    }
  }
  return out;
}

/** 单个字节串 -> 文本。UniGB-UCS2-H 等编码的码元就是 UCS-2 大端值 */
function decodeString(bytes, twoByte) {
  if (!twoByte) return bytes;
  let out = '';
  for (let i = 0; i + 1 < bytes.length; i += 2) {
    out += String.fromCharCode((bytes.charCodeAt(i) << 8) | bytes.charCodeAt(i + 1));
  }
  if (bytes.length % 2) out += bytes[bytes.length - 1];
  return out;
}

/**
 * 解释一段内容流，返回 text / rect 两类图元。
 * 坐标已用内容流最外层 cm 的逆矩阵还原为「页面所见坐标」。
 */
function parseContent(text, page, twoByte) {
  const items = [];
  const stack = [];
  let args = [];
  let ctm = [1, 0, 0, 1, 0, 0];
  let base = null;
  let tm = [1, 0, 0, 1, 0, 0];
  let tlm = tm;
  let fontSize = 12;
  let pendingStrings = [];

  TOKEN_RE.lastIndex = 0;
  let m;
  while ((m = TOKEN_RE.exec(text))) {
    const [, literal, hex, bracket, name, num, op, comment] = m;
    if (comment) continue;
    if (bracket) continue;
    if (literal !== undefined) {
      pendingStrings.push(unescapeLiteral(literal.slice(1, -1)));
      continue;
    }
    if (hex !== undefined) {
      let h = hex.slice(1, -1).replace(/\s+/g, '');
      if (h.length % 2) h += '0';
      let s = '';
      for (let i = 0; i < h.length; i += 2) s += String.fromCharCode(parseInt(h.substr(i, 2), 16));
      pendingStrings.push(s);
      continue;
    }
    if (name !== undefined) {
      args.push({ type: 'name', value: name.slice(1) });
      continue;
    }
    if (num !== undefined) {
      args.push({ type: 'num', value: Number(num) });
      continue;
    }
    const numbers = args.filter((a) => a.type === 'num').map((a) => a.value);
    switch (op) {
      case 'q':
        stack.push(ctm);
        break;
      case 'Q':
        if (stack.length) ctm = stack.pop();
        break;
      case 'cm':
        if (numbers.length >= 6) {
          ctm = mul(numbers.slice(-6), ctm);
          if (!base) base = ctm.slice();
        }
        break;
      case 'BT':
        tm = tlm = [1, 0, 0, 1, 0, 0];
        break;
      case 'Tm':
        if (numbers.length >= 6) tm = tlm = numbers.slice(-6);
        break;
      case 'Td':
      case 'TD':
        if (numbers.length >= 2) {
          tlm = mul([1, 0, 0, 1, numbers[numbers.length - 2], numbers[numbers.length - 1]], tlm);
          tm = tlm;
        }
        break;
      case 'Tf':
        if (numbers.length) fontSize = numbers[numbers.length - 1];
        break;
      case 'Tj':
      case 'TJ':
      case "'":
      case '"':
        if (pendingStrings.length) {
          const trm = mul(tm, ctm);
          const [x, y] = apply(trm, 0, 0);
          const scale = Math.hypot(trm[0], trm[1]) || 1;
          items.push({
            type: 'text',
            page,
            x,
            y,
            size: fontSize * scale,
            text: decodeString(pendingStrings[pendingStrings.length - 1], twoByte)
          });
        }
        break;
      case 're':
        if (numbers.length >= 4) {
          const [x, y, w, h] = numbers.slice(-4);
          const p1 = apply(ctm, x, y);
          const p2 = apply(ctm, x + w, y + h);
          items.push({
            type: 'rect',
            page,
            x: Math.min(p1[0], p2[0]),
            y: Math.min(p1[1], p2[1]),
            w: Math.abs(p2[0] - p1[0]),
            h: Math.abs(p2[1] - p1[1])
          });
        }
        break;
      default:
        break;
    }
    args = [];
    pendingStrings = [];
  }

  if (base) {
    const inv = invert(base);
    return items.map((it) => {
      const [cx, cy] = apply(inv, it.x, it.y);
      const [cx2, cy2] = apply(inv, it.x + (it.w || 0), it.y + (it.h || 0));
      const out = { ...it, x: cx, y: cy };
      if (it.type === 'rect') {
        out.w = Math.abs(cx2 - cx);
        out.h = Math.abs(cy2 - cy);
        out.x = Math.min(cx, cx2);
        out.y = Math.min(cy, cy2);
      }
      return out;
    });
  }
  return items;
}

/** 解析整份 PDF，返回全部图元 */
async function extractItems(bytes) {
  const streams = await contentStreams(bytes);
  const items = [];
  for (const s of streams) items.push(...parseContent(s.text, s.page, s.twoByte));
  return { items, pageCount: streams.length };
}

// ------------------------------------------------------------ 课表结构还原

const DAY_CHARS = { 一: 1, 二: 2, 三: 3, 四: 4, 五: 5, 六: 6, 日: 7, 天: 7 };
const DAY_NAME_RE = /^星期\s*([一二三四五六日天])$/;
const PERIOD_LABEL_RE = /^(\d{1,2})\s*-\s*(\d{1,2})$/;
const FIELD_RE = /(周数|校区|地点|教师|教学班组成|教学班|选课备注|课程学时组成)\s*[:：]/g;
/** 明细行一定包含这些关键词，课程名一般不会 */
const DETAIL_KEY_RE = /周数\s*[:：]|校区\s*[:：]|地点\s*[:：]|教师\s*[:：]|教学班|学时组成/;

const round1 = (v) => Math.round(v * 10) / 10;
const topDown = (a, b) => b.y - a.y;

/** 解析「2-5周,8-19周」这类周次描述 */
function parseWeekRanges(str) {
  const ranges = [];
  if (!str) return ranges;
  const re = /(\d{1,2})(?:\s*-\s*(\d{1,2}))?\s*周/g;
  let m;
  while ((m = re.exec(str))) {
    const from = Number(m[1]);
    const to = m[2] ? Number(m[2]) : from;
    ranges.push([Math.min(from, to), Math.max(from, to)]);
  }
  return ranges;
}

/** 判断某周是否落在周次区间里 */
function inWeeks(weekRanges, week) {
  if (!weekRanges || !weekRanges.length) return true;
  return weekRanges.some(([a, b]) => week >= a && week <= b);
}

/** 拆分课程明细串 */
function parseDetail(raw) {
  const out = { raw: (raw || '').trim() };
  FIELD_RE.lastIndex = 0;
  const hits = [];
  let m;
  while ((m = FIELD_RE.exec(out.raw))) hits.push({ key: m[1], start: m.index, end: FIELD_RE.lastIndex });
  hits.forEach((hit, idx) => {
    const value = out.raw.slice(hit.end, idx + 1 < hits.length ? hits[idx + 1].start : out.raw.length);
    out[hit.key] = value.replace(/\s+/g, ' ').replace(/^[\/\s]+|[\/\s]+$/g, '').trim();
  });
  out.weekRanges = parseWeekRanges(out['周数']);
  return out;
}

/** 解析页脚「其他课程：课程名教师(共N周)/周次/地点; ...」 */
function parseOtherCourses(text) {
  return text
    .replace(/^其他课程\s*[:：]?/, '')
    .split(/[;；]/)
    .map((s) => s.trim())
    .filter(Boolean)
    .map((s) => {
      const m = /^(.*?)\s*\(共\s*(\d+)\s*周\)\s*\/\s*([^/]*)\s*\/\s*(.*)$/.exec(s);
      if (!m) return { name: s, teachers: '', totalWeeks: '', weeks: '', location: '', raw: s };
      const head = m[1].trim();
      const split = /^([^A-Za-z]+)([A-Za-z][\s\S]*)$/.exec(head);
      return {
        name: split ? split[1].trim() : head,
        teachers: split ? split[2].trim() : '',
        totalWeeks: m[2],
        weeks: m[3].trim(),
        location: m[4].trim(),
        raw: s
      };
    });
}

/**
 * 把图元还原成结构化课表。
 * 表格结构：最左列是「星期」分组格，第二列是节次格，右侧整行是课程明细行。
 */
function buildSchedule(items, fileMeta = {}) {
  const texts = items.filter((i) => i.type === 'text' && i.text && i.text.trim());
  const rects = items.filter((i) => i.type === 'rect' && i.w > 1 && i.h > 1);
  const pages = [...new Set(items.map((i) => i.page))].sort((a, b) => a - b);

  const layout = new Map(); // page -> { dayCells, periodCells, rowRects, bodyX, firstX, restX }
  for (const page of pages) {
    const pageRects = rects.filter((r) => r.page === page);
    if (!pageRects.length) continue;
    const leftX = Math.min(...pageRects.map((r) => r.x));
    const leftCol = pageRects.filter((r) => Math.abs(r.x - leftX) < 1);
    const colW = Math.min(...leftCol.map((r) => r.w));
    const dayCells = leftCol.filter((r) => r.w <= colW + 0.5).sort(topDown);

    const right = pageRects.filter((r) => r.x > leftX + colW - 1);
    if (!right.length) continue;
    const periodX = Math.min(...right.map((r) => r.x));
    const periodCol = right.filter((r) => Math.abs(r.x - periodX) < 1);
    const colW2 = Math.min(...periodCol.map((r) => r.w));
    const periodCells = periodCol.filter((r) => r.w <= colW2 + 0.5).sort(topDown);

    const bodyRects = right.filter((r) => r.x > periodX + colW2 - 1);
    const bodyW = bodyRects.length ? Math.min(...bodyRects.map((r) => r.w)) : 0;
    const rowRects = bodyRects.filter((r) => r.w >= bodyW - 0.5).sort(topDown);
    const bodyX = bodyRects.length ? Math.min(...bodyRects.map((r) => r.x)) : 0;

    const pageTexts = texts.filter((t) => t.page === page);
    const rowTexts = pageTexts.filter(
      (t) => t.size < 20 && t.x >= bodyX - 4
        && rowRects.some((r) => t.y >= r.y - 1 && t.y <= r.y + r.h + 1)
    );
    const counts = new Map();
    for (const t of rowTexts) counts.set(round1(t.x), (counts.get(round1(t.x)) || 0) + 1);
    const cols = [...counts.entries()].sort((a, b) => b[1] - a[1]).map((e) => e[0]);
    layout.set(page, { dayCells, periodCells, rowRects, bodyX, firstX: cols[0], restX: cols[1] });
  }

  const meta = {
    student: '',
    studentId: '',
    term: '',
    printedAt: '',
    source: fileMeta.source || '',
    importedAt: fileMeta.importedAt || new Date().toISOString()
  };
  const dayMap = new Map(); // dayNumber -> { day, name, slots: Map }
  const others = [];
  const warnings = [];
  let lastDay = null;

  const ensureDay = (day, name) => {
    if (!dayMap.has(day)) dayMap.set(day, { day, name, slots: new Map() });
    const entry = dayMap.get(day);
    if (name) entry.name = name;
    return entry;
  };

  for (const page of pages) {
    const lay = layout.get(page);
    if (!lay) continue;
    const pageTexts = texts.filter((t) => t.page === page);

    // ---- 页眉页脚等全局文字
    for (const t of pageTexts) {
      const value = t.text.trim();
      if (!meta.term && /学年第\s*\d\s*学期/.test(value)) meta.term = value;
      const idm = /学号\s*[:：]\s*(\w+)/.exec(value);
      if (idm) meta.studentId = idm[1];
      if (!meta.printedAt) {
        const dm = /打印时间\s*[:：]?\s*(\d{4}-\d{2}-\d{2})/.exec(value);
        if (dm) meta.printedAt = dm[1];
      }
      if (!meta.student && t.size >= 18 && /课表\s*$/.test(value)) {
        meta.student = value.replace(/课表\s*$/, '');
      }
      if (/^其他课程/.test(value)) continue; // 页脚统一在整页文字合并后再解析
    }

    // ---- 星期分组格 -> 星期编号；没有名字的格子按「分页续排」归到上一页最后一天
    const pageDays = [];
    for (const cell of lay.dayCells) {
      const nameText = pageTexts.find(
        (t) => DAY_NAME_RE.test(t.text.trim())
          && t.y >= cell.y - 2 && t.y <= cell.y + cell.h + 2
      );
      if (nameText) {
        const ch = DAY_NAME_RE.exec(nameText.text.trim())[1];
        lastDay = DAY_CHARS[ch];
        pageDays.push(ensureDay(lastDay, nameText.text.trim()));
      } else if (lastDay) {
        pageDays.push(ensureDay(lastDay, ''));
      } else {
        pageDays.push(null);
      }
    }

    // ---- 逐行还原课程
    for (const row of lay.rowRects) {
      const rowTexts = pageTexts
        .filter((t) => t.y >= row.y - 1 && t.y <= row.y + row.h + 1 && t.x > lay.bodyX - 4)
        .sort((a, b) => b.y - a.y);
      if (!rowTexts.length) continue;

      const middle = row.y + row.h / 2;
      const periodCell = lay.periodCells.find((c) => middle >= c.y - 1 && middle <= c.y + c.h + 1);
      let periodLabel = '';
      if (periodCell) {
        const labelText = texts.find(
          (t) => t.page === page && PERIOD_LABEL_RE.test(t.text.trim())
            && t.y >= periodCell.y - 2 && t.y <= periodCell.y + periodCell.h + 2
        );
        if (labelText) periodLabel = labelText.text.trim();
      }
      const dayCell = lay.dayCells.find((c) => middle >= c.y - 1 && middle <= c.y + c.h + 1);
      const dayEntry = dayCell ? pageDays[lay.dayCells.indexOf(dayCell)] : pageDays[pageDays.length - 1];
      if (!dayEntry) {
        warnings.push(`第 ${page} 页有 1 行课程没能确定所属星期，已跳过。`);
        continue;
      }

      const keyed = rowTexts.filter((t) => DETAIL_KEY_RE.test(t.text));
      const detailX = keyed.length ? keyed[0].x : lay.firstX;
      const detailTexts = rowTexts.filter((t) => Math.abs(t.x - detailX) < 2);
      const nameTexts = rowTexts.filter((t) => Math.abs(t.x - detailX) >= 2);
      const name = nameTexts.map((t) => t.text.trim()).join('');
      const detail = parseDetail(detailTexts.map((t) => t.text).join(''));
      if (!name && !detail.raw) continue;

      const course = {
        name: name || detail['教学班'] || '未命名课程',
        weeks: detail['周数'] || '',
        weekRanges: detail.weekRanges,
        campus: detail['校区'] || '',
        location: detail['地点'] || '',
        teachers: detail['教师'] || '',
        className: detail['教学班'] || '',
        classInfo: detail['教学班组成'] || '',
        note: detail['选课备注'] || '',
        hours: detail['课程学时组成'] || ''
      };

      const slotKey = periodLabel || '未标注节次';
      if (!dayEntry.slots.has(slotKey)) {
        const pm = PERIOD_LABEL_RE.exec(slotKey.replace(/\s/g, ''));
        dayEntry.slots.set(slotKey, {
          label: slotKey,
          start: pm ? Number(pm[1]) : null,
          end: pm ? Number(pm[2]) : null,
          courses: []
        });
      }
      dayEntry.slots.get(slotKey).courses.push(course);
    }

    // ---- 页脚「其他课程：…」
    const loose = pageTexts
      .filter((t) => !lay.rowRects.some((r) => t.y >= r.y - 1 && t.y <= r.y + r.h + 1)
        && !DAY_NAME_RE.test(t.text.trim()) && !PERIOD_LABEL_RE.test(t.text.trim())
        && t.size >= 9 && t.size <= 11 && t.text.trim().length > 2)
      .sort((a, b) => b.y - a.y)
      .map((t) => t.text)
      .join('');
    if (/^其他课程/.test(loose.trim())) others.push(...parseOtherCourses(loose.trim()));
  }

  const days = [...dayMap.values()]
    .sort((a, b) => a.day - b.day)
    .map((d) => ({
      day: d.day,
      name: d.name || `星期${'一二三四五六日'[d.day - 1]}`,
      slots: [...d.slots.values()].sort((a, b) => (a.start || 99) - (b.start || 99))
    }));

  if (!days.length) warnings.push('没有从 PDF 里解析出任何课程，请确认这是教务系统导出的课表文件。');

  return { meta, days, others, warnings };
}

/** 完整流程：PDF 字节 -> 课表对象 */
async function parseTimetablePdf(bytes, fileMeta = {}) {
  const { items, pageCount } = await extractItems(bytes);
  const schedule = buildSchedule(items, fileMeta);
  schedule.pageCount = pageCount;
  return schedule;
}

  global.TimetablePdf = {
    latin1,
    bytesFromLatin1,
    parseContent,
    extractItems,
    buildSchedule,
    parseWeekRanges,
    inWeeks,
    parseTimetablePdf
  };
})(typeof window !== 'undefined' ? window : globalThis);



