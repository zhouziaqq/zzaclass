/**
 * store.js —— 本地状态（视图、主题、开学日期、导入的课表）
 */

(function (global) {
'use strict';

const KEY = 'course-schedule:v1';

/** 默认开学日（第 1 周周一）：按课表打印日期所在周为第 2 周推算 */
const DEFAULT_TERM_START = '2026-08-31';

const defaults = {
  view: 'day',
  theme: '',
  termStart: DEFAULT_TERM_START,
  showAllWeeks: false,
  imported: null,
  importedName: '',
  custom: [],
  welcome: true,        // 是否显示「肘子大王」欢迎动画
  dayFormat: 'card',    // 当天视图格式：card / compact / timeline
  weekFormat: 'grid',   // 周课表格式：grid / classic
  device: 'auto'        // 界面端：auto / mobile / desktop
};

function load() {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return { ...defaults };
    return { ...defaults, ...JSON.parse(raw) };
  } catch (err) {
    console.warn('读取本地状态失败', err);
    return { ...defaults };
  }
}

function save(state) {
  try {
    localStorage.setItem(KEY, JSON.stringify(state));
  } catch (err) {
    console.warn('保存本地状态失败', err);
  }
}

function reset(state) {
  state.imported = null;
  state.importedName = '';
  save(state);
}

/** 当前使用的课表：优先导入的，否则用内置数据 */
function currentSchedule(state) {
  return state.imported || window.DEFAULT_SCHEDULE || { meta: {}, days: [], others: [], warnings: [] };
}

/** 统计课表里的课次数量 */
function countCourses(schedule) {
  return (schedule.days || []).reduce(
    (n, d) => n + (d.slots || []).reduce((m, s) => m + (s.courses || []).length, 0), 0);
}

/** 下载 JSON */
function downloadJson(schedule, fileName) {
  const blob = new Blob([JSON.stringify(schedule, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = fileName;
  a.click();
  URL.revokeObjectURL(url);
}

  global.Store = {
    DEFAULT_TERM_START,
    load,
    save,
    reset,
    currentSchedule,
    countCourses,
    downloadJson
  };
})(typeof window !== 'undefined' ? window : globalThis);
