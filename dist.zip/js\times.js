/**
 * times.js —— 节次时间表
 *
 * 规则（按学校作息）：
 *   · 每节课 45 分钟，课间休息 10 分钟；
 *   · 第 1 节 08:20 开始；
 *   · 第 3 节 10:20 开始（第 2 节后是大课间，休息 20 分钟）；
 *   · 第 5 节 14:00 开始（12:00 - 14:00 是午休）；
 *   · 第 9 节 18:30 开始（17:30 - 18:30 是晚饭），于是第 11 节正好 20:20 开始。
 */

(function (global) {
'use strict';

const LESSON_MINUTES = 45;
const BREAK_MINUTES = 10;

/** 每天的作息锚点：第 N 节从 HH:MM 开始（锚点之间按 45 + 10 分钟递推） */
const DEFAULT_ANCHORS = [
  [1, '08:20'],
  [3, '10:20'],
  [5, '14:00'],
  [9, '18:30']
];

const MAX_PERIODS = 12;

/** 上午 / 下午 / 晚上三个时段的划分 */
const BLOCKS = [
  { id: 'am', name: '上午', from: 1, to: 4 },
  { id: 'pm', name: '下午', from: 5, to: 8 },
  { id: 'night', name: '晚上', from: 9, to: 12 }
];

function toMinutes(hhmm) {
  const [h, m] = hhmm.split(':').map(Number);
  return h * 60 + m;
}

function formatMinutes(total) {
  const m = ((total % 1440) + 1440) % 1440;
  return `${String(Math.floor(m / 60)).padStart(2, '0')}:${String(m % 60).padStart(2, '0')}`;
}

/** 生成 1..MAX_PERIODS 节的起止时间 */
function buildPeriodTimes({
  lesson = LESSON_MINUTES,
  rest = BREAK_MINUTES,
  anchors = DEFAULT_ANCHORS,
  maxPeriod = MAX_PERIODS
} = {}) {
  const list = [];
  for (let period = 1; period <= maxPeriod; period++) {
    const anchor = anchors.filter(([start]) => start <= period).pop() || anchors[0];
    const startMinutes = toMinutes(anchor[1]) + (period - anchor[0]) * (lesson + rest);
    list.push({
      period,
      startMinutes,
      endMinutes: startMinutes + lesson,
      start: formatMinutes(startMinutes),
      end: formatMinutes(startMinutes + lesson)
    });
  }
  return list;
}

const PERIOD_TIMES = buildPeriodTimes();

function periodTime(period) {
  return PERIOD_TIMES[period - 1] || null;
}

/** 某个节次区间（如 5-6 节）的起止时间 */
function slotTime(start, end) {
  const a = periodTime(start);
  const b = periodTime(end || start);
  if (!a || !b) return { start: '', end: '', startMinutes: null, endMinutes: null };
  return {
    start: a.start,
    end: b.end,
    startMinutes: a.startMinutes,
    endMinutes: b.endMinutes
  };
}

/** 两个节次之间是不是跨了午休 / 晚饭 / 大课间 */
function gapBetween(fromPeriod, toPeriod) {
  const a = periodTime(fromPeriod);
  const b = periodTime(toPeriod);
  if (!a || !b) return null;
  const gap = b.startMinutes - a.endMinutes;
  if (gap <= BREAK_MINUTES) return null;
  const name = b.startMinutes >= toMinutes('18:00') ? '晚饭'
    : (b.startMinutes >= toMinutes('13:00') ? '午休'
      : (gap >= 15 ? '大课间' : '课间休息'));
  return {
    minutes: gap,
    name,
    start: a.end,
    end: b.start
  };
}

/** 当前时间是否落在某一节课内 */
function currentPeriod(now = new Date()) {
  const minutes = now.getHours() * 60 + now.getMinutes();
  return PERIOD_TIMES.find((p) => minutes >= p.startMinutes && minutes < p.endMinutes) || null;
}

/** 距离某节开始还有多久（分钟，可能为负） */
function minutesUntil(period, now = new Date()) {
  const p = periodTime(period);
  if (!p) return null;
  return p.startMinutes - (now.getHours() * 60 + now.getMinutes());
}

  global.Times = {
    LESSON_MINUTES,
    BREAK_MINUTES,
    DEFAULT_ANCHORS,
    MAX_PERIODS,
    BLOCKS,
    PERIOD_TIMES,
    toMinutes,
    formatMinutes,
    buildPeriodTimes,
    periodTime,
    slotTime,
    gapBetween,
    currentPeriod,
    minutesUntil
  };
})(typeof window !== 'undefined' ? window : globalThis);
